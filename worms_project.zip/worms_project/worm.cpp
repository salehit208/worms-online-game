#include <worm.h>
#include <coordinates.h>
#include <iostream>
using namespace std;
worm::worm(coordinates head, coordinates tail, char rasta_h,char rasta_t)
{
    this->head =head;
    this->tail = tail ;
    this->rasta_head =rasta_h;
    this->rasta_tail=rasta_t ;
    speed =1 ;
    increase =1 ;
    decrease = 2 ;
    initial_lenght = 3 ;
    lenght=initial_lenght ;
}

void worm::move_tail()
{
    int breaking_points_number =breaking_points.size();
    if(rasta_tail=='h')
    {

        coordinates the_last_breaking_point =breaking_points[breaking_points_number-1];
        if(the_last_breaking_point.Xposition>tail.Xposition)
            tail.Xposition+=speed ;
        else
             tail.Xposition-=speed ;
        if(tail.Xposition == the_last_breaking_point.Xposition)
        {
            breaking_points.pop_back();
            rasta_tail='v';
        }

    }
    else
    {

        coordinates the_last_breaking_point =breaking_points[breaking_points_number-1];
        if(the_last_breaking_point.Yposition>tail.Yposition)
            tail.Yposition+=speed ;
        else
             tail.Yposition-=speed ;
        if(tail.Yposition == the_last_breaking_point.Yposition)
        {
            breaking_points.pop_back();
            rasta_tail ='h';
        }

    }
}

void worm::move(char jahat)
{
    if(rasta_head == 'h')
    {
        if(jahat == 'u' || jahat == 'd')
        {
            rasta_head='v';
            int breaking_points_number =breaking_points.size();
            breaking_points.resize(breaking_points_number +1);
            breaking_points_number+=1;
            for(int i=breaking_points_number-1;i>0;i--)
            {
               breaking_points[i]=breaking_points[i-1];
            }
            breaking_points[0]=head ;
            move_tail();
            if(jahat == 'u')
            {
               // cout << "1"<<endl ;
                if(speed > head.Yposition)
                    head.Yposition = 0;
                else
                    head.Yposition =head.Yposition- speed ;
            }
            else
            {
               head.Yposition += speed ;
            }
        }
        else
        {
          if(breaking_points.size()== 0)
          {
              if(head.Xposition > tail.Xposition)
              {
                  if(jahat == 'r')
                  {
                    head.Xposition+=speed;
                    tail.Xposition += speed;
                  }
                  else
                  {
                      decrease_lenght();
                  }
              }
              else
              {
                if(jahat == 'l')
                {
                 if(speed> head.Xposition)
                     head.Xposition =0 ;
                 else
                     head.Xposition -=speed ;
                 tail.Xposition -=speed ;
                }
                else
                {
                    decrease_lenght();
                }
              }
          }
          else
          {
            coordinates first_breaking_point = breaking_points[0];
            if(head.Xposition > first_breaking_point.Xposition)
            {
                if(jahat=='r')
                {
                   head.Xposition += speed ;
                   move_tail();
                }
                else
                {
                    decrease_lenght();
                }
            }
            else
            {
                if(jahat == 'l')
                {
                    if(speed > head.Xposition)
                        head.Xposition =0;
                    else
                        head.Xposition -= speed ;
                    move_tail();
                }
                else
                {
                   decrease_lenght();
                }
            }
          }
        }
    }
    else
    {
      if(jahat == 'r' || jahat== 'l')
      {
          rasta_head='h';
          int breaking_points_number =breaking_points.size();
          breaking_points.resize(breaking_points_number +1);
          breaking_points_number+=1;
          for(int i=breaking_points_number-1;i>0;i--)
          {
             breaking_points[i]=breaking_points[i-1];
          }
          breaking_points[0]=head ;
          move_tail();
          if(jahat == 'l')
          {
             if(speed > head.Xposition)
                 head.Xposition =0 ;
             else
                  head.Xposition -= speed ;
          }
          else
          {
             head.Xposition += speed ;
          }

      }
      else
      {
          if(breaking_points.size()==0)
          {
              if(head.Yposition < tail.Yposition)
              {
                  if(jahat == 'u')
                  {
                      if(speed > head.Yposition)
                          head.Yposition =0 ;
                      else
                          head.Yposition -= speed;
                      tail.Yposition -= speed;
                  }
                  else
                  {
                      decrease_lenght();
                  }
              }
              else
              {
                  if(jahat == 'd')
                  {
                      head.Yposition += speed;
                      tail.Yposition += speed;
                  }
                  else
                  {
                      decrease_lenght();
                  }
              }
          }
          else
          {
              coordinates first_breaking_point = breaking_points[0];
              if(head.Yposition< first_breaking_point.Yposition)
              {
                  if(jahat== 'u')
                  {
                      if(speed > head.Yposition)
                          head.Yposition =0;
                      else
                          head.Yposition -= speed ;
                      move_tail();
                  }
                  else
                  {
                      decrease_lenght();
                  }
              }
              else
              {
                  if(jahat == 'd')
                  {
                      head.Yposition += speed ;
                      move_tail();
                  }
                  else
                  {
                      decrease_lenght();
                  }
              }
          }
      }
    }
}

void worm::decrease_lenght()
{
   if(lenght <= 4)
      {
       lenght=0;
       breaking_points.clear();
       head=tail ;
       return ;
      }
   lenght -= decrease;
   coordinates first_breaking_point;
   bool not_to_exit=true ;
   int decrease_per_time = decrease ;
   while (not_to_exit)
   {
       if(breaking_points.size()==0)
       {
         if(rasta_head == 'h')
         {
            if(head.Xposition >tail.Xposition)
            {
                head.Xposition-= decrease ;
                not_to_exit = false ;
            }
            else
            {
                head.Xposition+= decrease ;
                not_to_exit = false ;
            }
         }
         else
         {
             if(head.Yposition >tail.Yposition)
             {
                 head.Yposition-= decrease ;
                 not_to_exit = false ;
             }
             else
             {
                 head.Yposition+= decrease ;
                 not_to_exit = false ;
             }
         }
       }
       else
       {
        first_breaking_point = breaking_points[0];
        if(rasta_head == 'h')
        {
            if(head.Xposition>first_breaking_point.Xposition)
            {
                int distance=head.Xposition - first_breaking_point.Xposition;
                if(distance > decrease_per_time)
                {
                    head.Xposition -= decrease_per_time ;
                    not_to_exit = false ;
                }
                else
                {
                    if(distance == decrease_per_time)
                    {
                        head.Xposition -= decrease_per_time ;
                        for(int i=0;i<breaking_points.size()-1;i++)
                            breaking_points[i]=breaking_points[i+1];
                        breaking_points.pop_back();
                        rasta_head='v';
                        not_to_exit=false;

                    }
                    else
                    {
                        head.Xposition -= distance;
                        for(int i=0;i<breaking_points.size()-1;i++)
                            breaking_points[i]=breaking_points[i+1];
                        breaking_points.pop_back();
                        rasta_head='v';
                        decrease_per_time -= distance;
                    }
                }
            }
            else
            {
                int distance= first_breaking_point.Xposition-head.Xposition;
                if(distance > decrease_per_time)
                {
                    head.Xposition += decrease_per_time ;
                    not_to_exit = false ;
                }
                else
                {
                    if(distance == decrease_per_time)
                    {
                        head.Xposition += decrease_per_time ;
                        for(int i=0;i<breaking_points.size()-1;i++)
                            breaking_points[i]=breaking_points[i+1];
                        breaking_points.pop_back();
                        rasta_head='v';
                        not_to_exit=false;

                    }
                    else
                    {
                        head.Xposition += distance;
                        for(int i=0;i<breaking_points.size()-1;i++)
                            breaking_points[i]=breaking_points[i+1];
                        breaking_points.pop_back();
                        rasta_head='v';
                        decrease_per_time -= distance;
                    }
                }
            }
        }
        else
        {
            if(head.Yposition>first_breaking_point.Yposition)
            {
                int distance=head.Yposition - first_breaking_point.Yposition;
                if(distance > decrease_per_time)
                {
                    head.Yposition -= decrease_per_time ;
                    not_to_exit = false ;
                }
                else
                {
                    if(distance == decrease_per_time)
                    {
                        head.Yposition -= decrease_per_time ;
                        for(int i=0;i<breaking_points.size()-1;i++)
                            breaking_points[i]=breaking_points[i+1];
                        breaking_points.pop_back();
                        rasta_head='h';
                        not_to_exit=false;

                    }
                    else
                    {
                        head.Yposition -= distance;
                        for(int i=0;i<breaking_points.size()-1;i++)
                            breaking_points[i]=breaking_points[i+1];
                        breaking_points.pop_back();
                        rasta_head='h';
                        decrease_per_time -= distance;
                    }
                }
            }
            else
            {
                int distance= first_breaking_point.Yposition-head.Yposition;
                if(distance > decrease_per_time)
                {
                    head.Yposition += decrease_per_time ;
                    not_to_exit = false ;
                }
                else
                {
                    if(distance == decrease_per_time)
                    {
                        head.Yposition += decrease_per_time ;
                        for(int i=0;i<breaking_points.size()-1;i++)
                            breaking_points[i]=breaking_points[i+1];
                        breaking_points.pop_back();
                        rasta_head='h';
                        not_to_exit=false;

                    }
                    else
                    {
                        head.Yposition += distance;
                        for(int i=0;i<breaking_points.size()-1;i++)
                            breaking_points[i]=breaking_points[i+1];
                        breaking_points.pop_back();
                        rasta_head='h';
                        decrease_per_time -= distance;
                    }
                }
            }
        }
       }
   }
}

void worm::increase_lenght()
{
    lenght += increase ;
    if(rasta_head == 'h')
    {
       if(breaking_points.size()==0)
       {
           if(head.Xposition> tail.Xposition)
           {
               head.Xposition += increase;
           }
           else
           {
               if(increase > head.Xposition)
                   head.Xposition = 0;
               else
                   head.Xposition -= increase;
           }
       }
       else
       {
          coordinates first_breaking_point = breaking_points[0];
          if(head.Xposition > first_breaking_point.Xposition)
          {
              head.Xposition+=increase;
          }
          else
          {
              if(increase > head.Xposition)
                  head.Xposition = 0;
              else
                  head.Xposition-=increase;
          }
        }
    }
    else
    {
        if(breaking_points.size()==0)
        {
            if(head.Yposition> tail.Yposition)
            {
                head.Yposition += increase;
            }
            else
            {
                if(increase > head.Yposition)
                    head.Yposition = 0 ;
                else
                    head.Yposition -= increase;
            }
        }
        else
        {
           coordinates first_breaking_point = breaking_points[0];
           if(head.Yposition > first_breaking_point.Yposition)
           {
               head.Yposition+=increase;
           }
           else
           {
               if(increase > head.Yposition)
                   head.Yposition =0 ;
               else
                   head.Yposition-=increase;
           }
         }
    }
}

worm:: ~worm()
{
    breaking_points.clear();
}

void worm::self_smash()
{
    char X=head.Xposition;
    char Y=head.Yposition;
    if(breaking_points.size()>=3)
    {
      if(rasta_head == 'h')
      {
        if(head.Xposition>breaking_points[0].Xposition)
        {
          for(int i=0 ;i<breaking_points.size();i=i+2)
          {
              if(i==breaking_points.size()-1)
              {
                  if(X>=tail.Xposition && breaking_points[0].Xposition<tail.Xposition)
                  {
                      if(tail.Yposition>breaking_points[i].Yposition)
                      {
                          if(Y>=breaking_points[i].Yposition && Y<=tail.Yposition)
                          {
                              decrease_lenght();
                          }
                      }
                      else
                      {
                          if(Y>=tail.Yposition && Y<=breaking_points[i].Yposition)
                          {
                             decrease_lenght();
                          }
                      }
                  }
              }
              else
              {
                  if(X>=breaking_points[i].Xposition && breaking_points[0].Xposition<breaking_points[i].Xposition)
                  {
                      if(breaking_points[i].Yposition >breaking_points[i+1].Yposition)
                      {
                          if(Y>=breaking_points[i+1].Yposition && Y<=breaking_points[i].Yposition)
                          {
                            decrease_lenght();
                          }
                      }
                      else
                      {
                          if(Y>=breaking_points[i].Yposition && Y<=breaking_points[i+1].Yposition)
                          {
                              decrease_lenght();
                          }
                      }
                  }
              }
          }
        }
        else
        {
            for(int i=0 ;i<breaking_points.size();i=i+2)
            {
                if(i==breaking_points.size()-1)
                {
                    if(X<=tail.Xposition && breaking_points[0].Xposition >tail.Xposition)
                    {
                        if(tail.Yposition>breaking_points[i].Yposition)
                        {
                            if(Y>=breaking_points[i].Yposition && Y<=tail.Yposition)
                            {
                              decrease_lenght();
                            }
                        }
                        else
                        {
                            if(Y>=tail.Yposition && Y<=breaking_points[i].Yposition)
                            {
                               decrease_lenght();
                            }
                        }
                    }
                }
                else
                {
                    if(X<=breaking_points[i].Xposition && breaking_points[0].Xposition>=breaking_points[i].Xposition)
                    {
                        if(breaking_points[i].Yposition >breaking_points[i+1].Yposition)
                        {
                            if(Y>=breaking_points[i+1].Yposition && Y<=breaking_points[i].Yposition)
                            {
                                decrease_lenght();
                            }
                        }
                        else
                        {
                            if(Y>=breaking_points[i].Yposition && Y<=breaking_points[i+1].Yposition)
                            {
                               decrease_lenght();
                            }
                        }
                    }
                }
            }
        }
      }
      else
      {
         if(head.Yposition > breaking_points[0].Yposition)
         {
             for(int i=0 ;i<breaking_points.size();i=i+2)
             {
                 if(i==breaking_points.size()-1)
                 {
                     if(Y>=tail.Yposition && breaking_points[0].Yposition<tail.Yposition)
                     {
                         if(tail.Xposition>breaking_points[i].Xposition)
                         {
                             if(X>=breaking_points[i].Xposition && X<=tail.Xposition)
                             {
                                 decrease_lenght();
                             }
                         }
                         else
                         {
                             if(X>=tail.Xposition && X<=breaking_points[i].Xposition)
                             {
                                decrease_lenght();
                             }
                         }
                     }
                 }
                 else
                 {
                     if(Y>=breaking_points[i].Yposition && breaking_points[0].Yposition <breaking_points[i].Yposition)
                     {
                         if(breaking_points[i].Xposition>breaking_points[i+1].Xposition)
                         {
                             if(X>=breaking_points[i+1].Xposition && X<=breaking_points[i].Xposition)
                             {
                                 decrease_lenght();
                             }
                         }
                         else
                         {
                             if(X>=breaking_points[i].Xposition && X<=breaking_points[i+1].Xposition)
                             {
                                decrease_lenght();
                             }
                         }
                     }
                 }
             }
         }
         else
         {
             for(int i=0 ;i<breaking_points.size();i=i+2)
             {
                 if(i==breaking_points.size()-1)
                 {
                     if(Y<=tail.Yposition && breaking_points[0].Yposition >tail.Yposition)
                     {
                         if(tail.Xposition>breaking_points[i].Xposition)
                         {
                             if(X>=breaking_points[i].Xposition && X<=tail.Xposition)
                             {
                                 decrease_lenght();
                             }
                         }
                         else
                         {
                             if(X>=tail.Xposition && X<=breaking_points[i].Xposition)
                             {
                                decrease_lenght();
                             }
                         }
                     }
                 }
                 else
                 {
                     if(Y<=breaking_points[i].Yposition && breaking_points[0].Yposition>breaking_points[i].Yposition)
                     {
                         if(breaking_points[i].Xposition>breaking_points[i+1].Xposition)
                         {
                             if(X>=breaking_points[i+1].Xposition && X<=breaking_points[i].Xposition)
                             {
                                 decrease_lenght();
                             }
                         }
                         else
                         {
                             if(X>=breaking_points[i].Xposition && X<=breaking_points[i+1].Xposition)
                             {
                                decrease_lenght();
                             }
                         }
                     }
                 }
             }
         }
      }
    }
}

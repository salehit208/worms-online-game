#ifndef GAME_H
#define GAME_H

#include <QObject>
#include <user.h>
#include <vector>
#include <coordinates.h>
#include <QTimer>
#include <playground.h>
#include <string>
class game : public QObject
{
    Q_OBJECT
public:
    int id ;
    vector<user> users ;
    vector<coordinates> increasing_points ;
    QTimer * timer ;
    playground * ground ;
    explicit game(QObject *parent = 0,int id_game=0,playground * gr=NULL);

    void move_worm(string username,char jahat);
    void add_user(user u);
    ~game();
    void delete_user(int index);

 signals:
    void state_calculated(int game_id);
private slots:
    void calculate_state();

};

#endif // GAME_H

#include <QApplication>
#include <iostream>
#include <coordinates.h>
#include <vector>
#include <worm.h>
#include <playground.h>
#include <game.h>
#include <server.h>
#include <user.h>
#include <QHostAddress>
using namespace  std;
int main(int argc, char *argv[])
{
    QApplication app(argc, argv);
    server s ;
    app.exec();

}

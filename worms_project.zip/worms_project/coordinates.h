#ifndef COORDINATES_H
#define COORDINATES_H

class coordinates {
public:
    char Xposition;
    char Yposition;
};


#endif // COORDINATES_H

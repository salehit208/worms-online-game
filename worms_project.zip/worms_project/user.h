#include <worm.h>
#include <QHostAddress>
#include <string>
#ifndef USER_H
#define USER_H
class user{
public:
 short username_character_number;
 short password_character_number ;
 char * username ;
 char * password ;
 worm * w;
 QHostAddress address ;
 quint16 port ;
public:
 user(short ucn,short pcn,QHostAddress ipaddress,quint16 p,char * usern,char * pass);
 void creat_worm(coordinates head,coordinates tail,char rasta_h,char rasta_t);

};

#endif // USER_H

#include <user.h>
#include <coordinates.h>
user::user(short ucn, short pcn, QHostAddress ipaddress, quint16 p, char *usern, char *pass)
{
    username_character_number = ucn ;
    password_character_number = pcn ;
    username=new char[ucn+1];
    for(int i=0;i<ucn;i++)
        username[i]=usern[i];
    username[ucn]=0 ;
    password = new char[pcn+1] ;
    for(int i=0;i<pcn;i++)
        password[i]=pass[i];
    password[pcn]=0 ;
    address=ipaddress ;
    port=p ;

}
void user::creat_worm(coordinates head, coordinates tail, char rasta_h, char rasta_t)
{
    w=new worm(head,tail,rasta_h,rasta_t);
}


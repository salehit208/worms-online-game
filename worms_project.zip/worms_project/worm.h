#include <coordinates.h>
#include <vector>
using namespace  std;
#ifndef WORM_H
#define WORM_H

class worm{
public:
  coordinates head;
  vector<coordinates> breaking_points ;
  coordinates tail ;
  short speed  ;
  short increase  ;
  short decrease  ;
  short initial_lenght  ;
  char rasta_head ;
  char rasta_tail ;
  short lenght;

  worm(coordinates head,coordinates tail,char rasta_h,char rasta_t);
  ~worm();
public:

  void move(char jahat);
  void increase_lenght();
  void  decrease_lenght();
  void move_tail();
  void self_smash();
 };

#endif // WORM_H

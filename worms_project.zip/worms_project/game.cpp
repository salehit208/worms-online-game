#include "game.h"
#include <coordinates.h>
#include <iostream>
using namespace std ;
game::game(QObject *parent, int id_game, playground *gr) :
    QObject(parent)
{
      timer=new QTimer;
      id=id_game;
      ground=gr ;
       coordinates inc_point ;
       int Xvalue;
       int Yvalue;
       Xvalue = qrand()%13 ;
       Yvalue = qrand()%20 ;
       if(Xvalue == 0)
           Xvalue +=1;
       if(Yvalue == 0)
           Yvalue +=1 ;
       inc_point.Xposition = Xvalue ;
       inc_point.Yposition = Yvalue ;
       increasing_points.push_back(inc_point);
       Xvalue = qrand()%27 ;
       Yvalue = qrand()%20 ;
       if(Xvalue < 13)
           Xvalue +=14;
       if(Yvalue == 0)
           Yvalue +=1 ;
       inc_point.Xposition = Xvalue ;
       inc_point.Yposition = Yvalue ;
       increasing_points.push_back(inc_point);
       Xvalue = qrand()%13 ;
       Yvalue = qrand()%41 ;
       if(Xvalue == 0)
           Xvalue +=1;
       if(Yvalue < 20)
           Yvalue +=21 ;
       inc_point.Xposition = Xvalue ;
       inc_point.Yposition = Yvalue ;
       increasing_points.push_back(inc_point);
       Xvalue = qrand()%27 ;
       Yvalue = qrand()%41 ;
       if(Xvalue < 13)
           Xvalue +=14;
       if(Yvalue < 20)
           Yvalue +=21 ;
       inc_point.Xposition = Xvalue ;
       inc_point.Yposition = Yvalue ;
       increasing_points.push_back(inc_point);
       connect(timer,SIGNAL(timeout()),this,SLOT(calculate_state()));
}

void game::add_user(user u)
{
    users.push_back(u);
}
 void game::move_worm(string username, char jahat)
 {
    //this function moves the user worm according received jahat
     cout <<"moving worm"<<endl;
     int index ;

    for(int i=0;i<users.size();i++)
    {
        if(users[i].username==username)
        {
            index=i;
            break ;
        }
    }
    char X_befor_move =users[index].w->head.Xposition;
    char Y_befor_move = users[index].w->head.Yposition;
    users[index].w->move(jahat);
    char X=users[index].w->head.Xposition;
    char Y=users[index].w->head.Yposition;
    bool has_been_eaten[4]={false,false,false,false};
    for(int i=0;i<4;i++)
    {
        if(jahat =='r')
        {
            if(increasing_points[i].Yposition == Y &&(X_befor_move <=increasing_points[i].Xposition && X>=increasing_points[i].Xposition ))
                has_been_eaten[i]=true ;
        }
        if(jahat =='l')
        {
            if(increasing_points[i].Yposition == Y &&(X_befor_move >=increasing_points[i].Xposition && X<=increasing_points[i].Xposition ))
                has_been_eaten[i]=true ;
        }
        if(jahat =='d')
        {
            if(increasing_points[i].Xposition == X &&(Y_befor_move <= increasing_points[i].Yposition && Y>=increasing_points[i].Yposition))
                has_been_eaten[i]=true;
        }
        if(jahat =='u')
        {
            if(increasing_points[i].Xposition == X &&(Y_befor_move >= increasing_points[i].Yposition && Y<=increasing_points[i].Yposition))
                has_been_eaten[i]=true;
        }
    }
    if(ground->walls.size()==0)
    {
     for(int i=0;i<4;i++)
     {
        if(has_been_eaten[i]== true)
        {


             for(int j=0;j<users.size();j++)
             {
                 if(users[j].w->breaking_points.size() == 0)
                 {
                     if(users[j].w->rasta_head=='h')
                     {
                       if(users[j].w->head.Yposition==increasing_points[i].Yposition)
                       {
                         if(users[j].w->head.Xposition > users[j].w->tail.Xposition )
                         {
                             if(increasing_points[i].Xposition >= users[j].w->tail.Xposition && increasing_points[i].Xposition<=users[j].w->head.Xposition )
                             {
                                 continue;
                             }
                         }
                         else
                         {
                             if(increasing_points[i].Xposition >= users[j].w->head.Xposition && increasing_points[i].Xposition<=users[j].w->tail.Xposition )
                             {
                                 continue ;
                             }
                         }
                       }
                     }
                     else
                     {
                       if(users[j].w->head.Xposition==increasing_points[i].Xposition)
                        {
                         if(users[j].w->head.Yposition > users[j].w->tail.Yposition )
                         {
                             if(increasing_points[i].Yposition >=users[j].w->tail.Yposition && increasing_points[i].Yposition<= users[j].w->head.Yposition )
                             {
                                 continue ;
                             }
                         }
                         else
                         {
                             if(increasing_points[i].Yposition <=users[j].w->tail.Yposition && increasing_points[i].Yposition>= users[j].w->head.Yposition )
                             {
                                 continue ;
                             }
                         }
                        }
                     }
                 }
                 else
                 {
                     if(users[j].w->rasta_head =='h')
                     {
                         if(increasing_points[i].Yposition == users[j].w->head.Yposition )
                         {
                             if(users[j].w->head.Xposition > users[j].w->breaking_points[0].Xposition)
                             {
                                 if(increasing_points[i].Xposition >= users[j].w->breaking_points[0].Xposition &&  increasing_points[i].Xposition<=users[j].w->head.Xposition)
                                 {
                                     continue ;
                                 }
                             }
                             else
                             {
                                 if(increasing_points[i].Xposition <= users[j].w->breaking_points[0].Xposition &&  increasing_points[i].Xposition>=users[j].w->head.Xposition)
                                 {
                                     continue ;
                                 }
                             }
                         }
                     }
                     else
                     {
                         if(increasing_points[i].Xposition == users[j].w->head.Xposition )
                         {
                             if(users[j].w->head.Yposition > users[j].w->breaking_points[0].Yposition)
                             {
                               if(increasing_points[i].Yposition >= users[j].w->breaking_points[0].Yposition&& increasing_points[i].Yposition<= users[j].w->head.Yposition)
                               {
                                   continue;
                               }
                             }
                             else
                             {
                                 if(increasing_points[i].Yposition <= users[j].w->breaking_points[0].Yposition&& increasing_points[i].Yposition>= users[j].w->head.Yposition)
                                 {
                                     continue;
                                 }
                             }
                         }
                     }
                     bool not_to_eat =false ;
                     for(int k=0;k<users[j].w->breaking_points.size()-1;k++)
                     {
                         if(users[j].w->breaking_points[k].Xposition == users[j].w->breaking_points[k+1].Xposition)
                         {
                           if(increasing_points[i].Xposition ==users[j].w->breaking_points[k].Xposition)
                           {
                             if(users[j].w->breaking_points[k].Yposition> users[j].w->breaking_points[k+1].Yposition)
                             {
                                 if(increasing_points[i].Yposition >=users[j].w->breaking_points[k+1].Yposition && increasing_points[i].Yposition<=users[j].w->breaking_points[k].Yposition )
                                 {
                                     not_to_eat =true ;
                                     break ;
                                 }
                             }
                             else
                             {
                                 if(increasing_points[i].Yposition <=users[j].w->breaking_points[k+1].Yposition && increasing_points[i].Yposition>=users[j].w->breaking_points[k].Yposition )
                                 {
                                     not_to_eat =true ;
                                     break ;
                                 }
                             }
                           }
                         }
                         else
                         {
                            if(increasing_points[i].Yposition ==users[j].w->breaking_points[k].Yposition)
                            {
                                if(users[j].w->breaking_points[k].Xposition> users[j].w->breaking_points[k+1].Xposition)
                                {
                                    if(increasing_points[i].Xposition >= users[j].w->breaking_points[k+1].Xposition && increasing_points[i].Xposition<=users[j].w->breaking_points[k].Xposition)
                                    {
                                        not_to_eat =true ;
                                        break ;
                                    }
                                }
                                else
                                {
                                    if(increasing_points[i].Xposition <= users[j].w->breaking_points[k+1].Xposition && increasing_points[i].Xposition>=users[j].w->breaking_points[k].Xposition)
                                    {
                                        not_to_eat =true ;
                                        break ;
                                    }
                                }
                            }
                         }
                     }
                     if(not_to_eat == true)
                     {
                         continue ;
                     }
                     int t=users[j].w->breaking_points.size()-1;
                     if(users[j].w->rasta_tail =='h')
                     {
                         if(increasing_points[i].Yposition == users[j].w->tail.Yposition)
                         {
                             if(users[j].w->tail.Xposition > users[j].w->breaking_points[t].Xposition)
                             {
                                 if(increasing_points[i].Xposition >= users[j].w->breaking_points[t].Xposition && increasing_points[i].Xposition<=users[j].w->tail.Xposition )
                                 {
                                     continue ;
                                 }
                             }
                             else
                             {
                                 if(increasing_points[i].Xposition <= users[j].w->breaking_points[t].Xposition && increasing_points[i].Xposition>=users[j].w->tail.Xposition )
                                 {
                                     continue ;
                                 }
                             }
                         }
                     }
                     else
                     {
                         if(increasing_points[i].Xposition == users[j].w->tail.Xposition)
                         {
                             if(users[j].w->tail.Yposition > users[j].w->breaking_points[t].Yposition)
                             {
                                 if(increasing_points[i].Yposition>= users[j].w->breaking_points[t].Yposition && increasing_points[i].Yposition<=users[j].w->tail.Yposition )
                                 {
                                     continue ;
                                 }
                             }
                             else
                             {
                                 if(increasing_points[i].Yposition<= users[j].w->breaking_points[t].Yposition && increasing_points[i].Yposition>=users[j].w->tail.Yposition )
                                 {
                                     continue ;
                                 }
                             }
                         }
                     }
                 }
             }
             coordinates inc_point ;
             int Xvalue;
             int Yvalue;
            users[index].w->increase_lenght();
            if(i==0)
            {
                Xvalue = qrand()%13 ;
                Yvalue = qrand()%20 ;
                if(Xvalue == 0)
                    Xvalue +=1;
                if(Yvalue == 0)
                    Yvalue +=1 ;
                inc_point.Xposition = Xvalue ;
                inc_point.Yposition = Yvalue ;
                increasing_points[0]=inc_point;
            }
            if(i==1)
            {

                Xvalue = qrand()%27 ;
                Yvalue = qrand()%20 ;
                if(Xvalue < 13)
                    Xvalue +=14;
                if(Yvalue == 0)
                    Yvalue +=1 ;
                inc_point.Xposition = Xvalue ;
                inc_point.Yposition = Yvalue ;
                increasing_points[1]=inc_point;
            }
            if(i== 2)
            {
                Xvalue = qrand()%13 ;
                Yvalue = qrand()%41 ;
                if(Xvalue == 0)
                    Xvalue +=1;
                if(Yvalue < 20)
                    Yvalue +=21 ;
                inc_point.Xposition = Xvalue ;
                inc_point.Yposition = Yvalue ;
                increasing_points[2]=inc_point ;
            }
            if(i==3)
            {
                Xvalue = qrand()%27 ;
                Yvalue = qrand()%41 ;
                if(Xvalue < 13)
                    Xvalue +=14;
                if(Yvalue < 20)
                    Yvalue +=21 ;
                inc_point.Xposition = Xvalue ;
                inc_point.Yposition = Yvalue ;
                increasing_points[3]=inc_point ;
            }
        }
      }
      X=users[index].w->head.Xposition;
      Y=users[index].w->head.Yposition;
      cout <<users[index].username <<"  "<<(int )X << "  "<<(int)Y<<endl ;
      if((int)X==0 || (int)X>= 27)
      {
       users[index].w->decrease_lenght();

      }
      else
      {
       if((int)Y== 0 || (int)Y>= 41)
        {
         users[index].w->decrease_lenght();

        }
      }
     }
     else
     {
     //will be written in the next version.this game version only supports simple playground without any walls inside the ground
     }
     users[index].w->self_smash();


 }

 void game::calculate_state()
 {
    if(users.size()==0)
    {
        cout << " cs"<<endl;
    }
    int users_number = users.size();
    char X;
    char Y ;
    char fbx;
    char fby ;
    for(int i=0 ;i<users_number;i++)
    {
       if(users[i].w->lenght != 0)
        {
            X=users[i].w->head.Xposition ;
            Y=users[i].w->head.Yposition ;
            if(users[i].w->breaking_points.size()==0)
            {
                fbx=users[i].w->tail.Xposition;
                fby=users[i].w->tail.Yposition;
            }
            else
            {
                fbx=users[i].w->breaking_points[0].Xposition;
                fby=users[i].w->breaking_points[0].Yposition;
            }
            for(int j=0;j<users_number;j++)
            {
              if(j!=i && users[j].w->lenght!=0)
              {
                if(users[i].w->rasta_head == 'h')
                {

                   if(X > fbx)
                   {
                     if(users[j].w->breaking_points.size()==0)
                            {
                                if(users[j].w->rasta_head == 'h')
                                {
                                  if(Y == users[j].w->head.Yposition)
                                  {
                                     if(users[j].w->head.Xposition >users[j].w->tail.Xposition)
                                     {
                                           if((X>=users[j].w->tail.Xposition && X<=users[j].w->head.Xposition) ||(X>=users[j].w->head.Xposition && fbx<=users[j].w->tail.Xposition ) )
                                           {
                                               users[i].w->decrease_lenght();
                                               X=users[i].w->head.Xposition ;
                                               Y=users[i].w->head.Yposition ;
                                               if(users[i].w->breaking_points.size()==0)
                                               {
                                                   fbx=users[i].w->tail.Xposition;
                                                   fby=users[i].w->tail.Yposition;
                                               }
                                               else
                                               {
                                                   fbx=users[i].w->breaking_points[0].Xposition;
                                                   fby=users[i].w->breaking_points[0].Yposition;
                                               }
                                           }
                                     }
                                     else
                                     {
                                         if((X>=users[j].w->head.Xposition && X<=users[j].w->tail.Xposition )||(X>=users[j].w->tail.Xposition && fbx<=users[j].w->head.Xposition) )
                                         {
                                             users[i].w->decrease_lenght();
                                             users[j].w->decrease_lenght();
                                             X=users[i].w->head.Xposition ;
                                             Y=users[i].w->head.Yposition ;
                                             if(users[i].w->breaking_points.size()==0)
                                             {
                                                 fbx=users[i].w->tail.Xposition;
                                                 fby=users[i].w->tail.Yposition;
                                             }
                                             else
                                             {
                                                 fbx=users[i].w->breaking_points[0].Xposition;
                                                 fby=users[i].w->breaking_points[0].Yposition;
                                             }
                                         }
                                     }
                                  }
                                }
                                else
                                {
                                   if(X>=users[j].w->head.Xposition && fbx <users[j].w->head.Xposition )
                                   {
                                      if(users[j].w->head.Yposition > users[j].w->tail.Yposition )
                                      {
                                          if(Y>=users[j].w->tail.Yposition && Y<=users[j].w->head.Yposition)
                                          {
                                              users[i].w->decrease_lenght();
                                              X=users[i].w->head.Xposition ;
                                              Y=users[i].w->head.Yposition ;
                                              if(users[i].w->breaking_points.size()==0)
                                              {
                                                  fbx=users[i].w->tail.Xposition;
                                                  fby=users[i].w->tail.Yposition;
                                              }
                                              else
                                              {
                                                  fbx=users[i].w->breaking_points[0].Xposition;
                                                  fby=users[i].w->breaking_points[0].Yposition;
                                              }
                                          }
                                      }
                                      else
                                      {
                                          if(Y>=users[j].w->head.Yposition && Y<=users[j].w->tail.Yposition )
                                          {
                                              users[i].w->decrease_lenght();
                                              X=users[i].w->head.Xposition ;
                                              Y=users[i].w->head.Yposition ;
                                              if(users[i].w->breaking_points.size()==0)
                                              {
                                                  fbx=users[i].w->tail.Xposition;
                                                  fby=users[i].w->tail.Yposition;
                                              }
                                              else
                                              {
                                                  fbx=users[i].w->breaking_points[0].Xposition;
                                                  fby=users[i].w->breaking_points[0].Yposition;
                                              }
                                          }
                                      }
                                   }
                                }
                            }
                     else
                     {
                      if(users[j].w->rasta_head == 'h')
                      {
                         if(users[j].w->breaking_points.size()==1)
                                  {
                                      if(users[j].w->tail.Yposition > users[j].w->breaking_points[0].Yposition)
                                      {
                                          if(X>=users[j].w->tail.Xposition && fbx <=users[j].w->tail.Xposition )
                                          {
                                             if(Y == users[j].w->breaking_points[0].Yposition)
                                             {
                                                 if(users[j].w->head.Xposition >users[j].w->breaking_points[0].Xposition )
                                                 {
                                                     users[i].w->decrease_lenght();
                                                     X=users[i].w->head.Xposition ;
                                                     Y=users[i].w->head.Yposition ;
                                                     if(users[i].w->breaking_points.size()==0)
                                                     {
                                                         fbx=users[i].w->tail.Xposition;
                                                         fby=users[i].w->tail.Yposition;
                                                     }
                                                     else
                                                     {
                                                         fbx=users[i].w->breaking_points[0].Xposition;
                                                         fby=users[i].w->breaking_points[0].Yposition;
                                                     }
                                                 }
                                                 else
                                                 {
                                                     users[i].w->decrease_lenght();
                                                     users[j].w->decrease_lenght();
                                                     X=users[i].w->head.Xposition ;
                                                     Y=users[i].w->head.Yposition ;
                                                     if(users[i].w->breaking_points.size()==0)
                                                     {
                                                         fbx=users[i].w->tail.Xposition;
                                                         fby=users[i].w->tail.Yposition;
                                                     }
                                                     else
                                                     {
                                                         fbx=users[i].w->breaking_points[0].Xposition;
                                                         fby=users[i].w->breaking_points[0].Yposition;
                                                     }
                                                 }
                                             }
                                             else
                                             {
                                                if(Y>users[j].w->breaking_points[0].Yposition && Y<=users[j].w->tail.Yposition )
                                                {
                                                    users[i].w->decrease_lenght();
                                                    X=users[i].w->head.Xposition ;
                                                    Y=users[i].w->head.Yposition ;
                                                    if(users[i].w->breaking_points.size()==0)
                                                    {
                                                        fbx=users[i].w->tail.Xposition;
                                                        fby=users[i].w->tail.Yposition;
                                                    }
                                                    else
                                                    {
                                                        fbx=users[i].w->breaking_points[0].Xposition;
                                                        fby=users[i].w->breaking_points[0].Yposition;
                                                    }
                                                }
                                             }
                                          }

                                      }
                                      else
                                      {
                                          if(X>=users[j].w->tail.Xposition && fbx <=users[j].w->tail.Xposition )
                                          {
                                             if(Y == users[j].w->breaking_points[0].Yposition)
                                             {
                                                 if(users[j].w->head.Xposition >users[j].w->breaking_points[0].Xposition )
                                                 {
                                                     users[i].w->decrease_lenght();
                                                     X=users[i].w->head.Xposition ;
                                                     Y=users[i].w->head.Yposition ;
                                                     if(users[i].w->breaking_points.size()==0)
                                                     {
                                                         fbx=users[i].w->tail.Xposition;
                                                         fby=users[i].w->tail.Yposition;
                                                     }
                                                     else
                                                     {
                                                         fbx=users[i].w->breaking_points[0].Xposition;
                                                         fby=users[i].w->breaking_points[0].Yposition;
                                                     }
                                                 }
                                                 else
                                                 {
                                                     users[i].w->decrease_lenght();
                                                     users[j].w->decrease_lenght();
                                                     X=users[i].w->head.Xposition ;
                                                     Y=users[i].w->head.Yposition ;
                                                     if(users[i].w->breaking_points.size()==0)
                                                     {
                                                         fbx=users[i].w->tail.Xposition;
                                                         fby=users[i].w->tail.Yposition;
                                                     }
                                                     else
                                                     {
                                                         fbx=users[i].w->breaking_points[0].Xposition;
                                                         fby=users[i].w->breaking_points[0].Yposition;
                                                     }
                                                 }
                                             }
                                             else
                                             {
                                                 if(Y>=users[j].w->tail.Yposition && Y<users[j].w->breaking_points[0].Yposition)
                                                 {
                                                     users[i].w->decrease_lenght();
                                                     X=users[i].w->head.Xposition ;
                                                     Y=users[i].w->head.Yposition ;
                                                     if(users[i].w->breaking_points.size()==0)
                                                     {
                                                         fbx=users[i].w->tail.Xposition;
                                                         fby=users[i].w->tail.Yposition;
                                                     }
                                                     else
                                                     {
                                                         fbx=users[i].w->breaking_points[0].Xposition;
                                                         fby=users[i].w->breaking_points[0].Yposition;
                                                     }
                                                 }
                                             }
                                          }
                                      }
                                  }
                         else
                                  {
                                   for(int z=0;z<users[j].w->breaking_points.size()-1;z++)
                                   {
                                       if(users[j].w->breaking_points[z].Xposition == users[j].w->breaking_points[z+1].Xposition )
                                       {
                                         if(X>=users[j].w->breaking_points[z].Xposition && fbx<= users[j].w->breaking_points[z].Xposition)
                                         {
                                             if(z==0)
                                             {
                                              if(Y==users[j].w->breaking_points[0].Yposition)
                                              {
                                                  if(users[j].w->head.Xposition > users[j].w->breaking_points[0].Xposition)
                                                  {
                                                      users[i].w->decrease_lenght();
                                                      X=users[i].w->head.Xposition ;
                                                      Y=users[i].w->head.Yposition ;
                                                      if(users[i].w->breaking_points.size()==0)
                                                      {
                                                          fbx=users[i].w->tail.Xposition;
                                                          fby=users[i].w->tail.Yposition;
                                                      }
                                                      else
                                                      {
                                                          fbx=users[i].w->breaking_points[0].Xposition;
                                                          fby=users[i].w->breaking_points[0].Yposition;
                                                      }
                                                  }
                                                  else
                                                  {
                                                      users[i].w->decrease_lenght();
                                                      users[j].w->decrease_lenght();
                                                      X=users[i].w->head.Xposition ;
                                                      Y=users[i].w->head.Yposition ;
                                                      if(users[i].w->breaking_points.size()==0)
                                                      {
                                                          fbx=users[i].w->tail.Xposition;
                                                          fby=users[i].w->tail.Yposition;
                                                      }
                                                      else
                                                      {
                                                          fbx=users[i].w->breaking_points[0].Xposition;
                                                          fby=users[i].w->breaking_points[0].Yposition;
                                                      }
                                                  }
                                                  continue ;
                                              }
                                             }

                                             if(users[j].w->breaking_points[z].Yposition>users[j].w->breaking_points[z+1].Yposition)
                                             {
                                                 if(Y >=users[j].w->breaking_points[z+1].Yposition && Y<=users[j].w->breaking_points[z].Yposition)
                                                 {
                                                     users[i].w->decrease_lenght();
                                                     X=users[i].w->head.Xposition ;
                                                     Y=users[i].w->head.Yposition ;
                                                     if(users[i].w->breaking_points.size()==0)
                                                     {
                                                         fbx=users[i].w->tail.Xposition;
                                                         fby=users[i].w->tail.Yposition;
                                                     }
                                                     else
                                                     {
                                                         fbx=users[i].w->breaking_points[0].Xposition;
                                                         fby=users[i].w->breaking_points[0].Yposition;
                                                     }
                                                 }

                                             }
                                             else
                                             {
                                                 if(Y>=users[j].w->breaking_points[z].Yposition && Y<=users[j].w->breaking_points[z+1].Yposition)
                                                 {
                                                    users[i].w->decrease_lenght();
                                                    X=users[i].w->head.Xposition ;
                                                    Y=users[i].w->head.Yposition ;
                                                    if(users[i].w->breaking_points.size()==0)
                                                    {
                                                        fbx=users[i].w->tail.Xposition;
                                                        fby=users[i].w->tail.Yposition;
                                                    }
                                                    else
                                                    {
                                                        fbx=users[i].w->breaking_points[0].Xposition;
                                                        fby=users[i].w->breaking_points[0].Yposition;
                                                    }
                                                 }
                                             }

                                        }
                                      }

                                   }
                                   if(users[j].w->rasta_tail == 'v')
                                   {
                                       if(X>= users[j].w->tail.Xposition && fbx <= users[j].w->tail.Xposition)
                                       {
                                           int t=users[j].w->breaking_points.size()-1;
                                           if(users[j].w->tail.Yposition > users[j].w->breaking_points[t].Yposition )
                                           {
                                               if(Y >= users[j].w->breaking_points[t].Yposition && Y <=users[j].w->tail.Yposition  )
                                               {
                                                 users[i].w->decrease_lenght();
                                                 X=users[i].w->head.Xposition ;
                                                 Y=users[i].w->head.Yposition ;
                                                 if(users[i].w->breaking_points.size()==0)
                                                 {
                                                     fbx=users[i].w->tail.Xposition;
                                                     fby=users[i].w->tail.Yposition;
                                                 }
                                                 else
                                                 {
                                                     fbx=users[i].w->breaking_points[0].Xposition;
                                                     fby=users[i].w->breaking_points[0].Yposition;
                                                 }
                                               }
                                           }
                                           else
                                           {
                                               if(Y>=users[j].w->tail.Yposition && Y <= users[j].w->breaking_points[t].Yposition)
                                               {
                                                  users[i].w->decrease_lenght();
                                                  X=users[i].w->head.Xposition ;
                                                  Y=users[i].w->head.Yposition ;
                                                  if(users[i].w->breaking_points.size()==0)
                                                  {
                                                      fbx=users[i].w->tail.Xposition;
                                                      fby=users[i].w->tail.Yposition;
                                                  }
                                                  else
                                                  {
                                                      fbx=users[i].w->breaking_points[0].Xposition;
                                                      fby=users[i].w->breaking_points[0].Yposition;
                                                  }
                                               }
                                           }
                                       }
                                   }


                              }
                      }
                      else
                              {
                                 if(X>= users[j].w->head.Xposition && fbx <= users[j].w->head.Xposition)
                                 {
                                     if(users[j].w->head.Yposition > users[j].w->breaking_points[0].Yposition)
                                     {
                                         if(Y>=users[j].w->breaking_points[0].Yposition && Y<=users[j].w->head.Yposition)
                                         {
                                             users[i].w->decrease_lenght();
                                             X=users[i].w->head.Xposition ;
                                             Y=users[i].w->head.Yposition ;
                                             if(users[i].w->breaking_points.size()==0)
                                             {
                                                 fbx=users[i].w->tail.Xposition;
                                                 fby=users[i].w->tail.Yposition;
                                             }
                                             else
                                             {
                                                 fbx=users[i].w->breaking_points[0].Xposition;
                                                 fby=users[i].w->breaking_points[0].Yposition;
                                             }

                                         }
                                     }
                                     else
                                     {
                                         if(Y>=users[j].w->head.Yposition && Y<=users[j].w->breaking_points[0].Yposition)
                                         {
                                             users[i].w->decrease_lenght();
                                             X=users[i].w->head.Xposition ;
                                             Y=users[i].w->head.Yposition ;
                                             if(users[i].w->breaking_points.size()==0)
                                             {
                                                 fbx=users[i].w->tail.Xposition;
                                                 fby=users[i].w->tail.Yposition;
                                             }
                                             else
                                             {
                                                 fbx=users[i].w->breaking_points[0].Xposition;
                                                 fby=users[i].w->breaking_points[0].Yposition;
                                             }
                                         }
                                     }
                                 }
                                 for(int z=0;z<users[j].w->breaking_points.size()-1;z++)
                                 {
                                     if(users[j].w->breaking_points[z].Xposition==users[j].w->breaking_points[z+1].Xposition)
                                     {
                                         if(X>=users[j].w->breaking_points[z].Xposition && fbx<=users[j].w->breaking_points[z].Xposition)
                                         {
                                             if(users[j].w->breaking_points[z].Yposition >users[j].w->breaking_points[z+1].Yposition)
                                             {
                                                 if(Y>=users[j].w->breaking_points[z+1].Yposition && Y<=users[j].w->breaking_points[z].Yposition)
                                                 {
                                                     users[i].w->decrease_lenght();
                                                     X=users[i].w->head.Xposition ;
                                                     Y=users[i].w->head.Yposition ;
                                                     if(users[i].w->breaking_points.size()==0)
                                                     {
                                                         fbx=users[i].w->tail.Xposition;
                                                         fby=users[i].w->tail.Yposition;
                                                     }
                                                     else
                                                     {
                                                         fbx=users[i].w->breaking_points[0].Xposition;
                                                         fby=users[i].w->breaking_points[0].Yposition;
                                                     }
                                                 }
                                             }
                                             else
                                             {
                                                 if(Y>=users[j].w->breaking_points[z].Yposition && Y<=users[j].w->breaking_points[z+1].Yposition)
                                                 {
                                                     users[i].w->decrease_lenght();
                                                     X=users[i].w->head.Xposition ;
                                                     Y=users[i].w->head.Yposition ;
                                                     if(users[i].w->breaking_points.size()==0)
                                                     {
                                                         fbx=users[i].w->tail.Xposition;
                                                         fby=users[i].w->tail.Yposition;
                                                     }
                                                     else
                                                     {
                                                         fbx=users[i].w->breaking_points[0].Xposition;
                                                         fby=users[i].w->breaking_points[0].Yposition;
                                                     }
                                                 }
                                             }
                                         }
                                     }
                                 }
                                 if(users[j].w->rasta_tail=='v')
                                 {
                                     int t=users[j].w->breaking_points.size()-1;
                                     if(X>=users[j].w->tail.Xposition && fbx<=users[j].w->tail.Xposition)
                                     {
                                         if(users[j].w->tail.Yposition > users[j].w->breaking_points[t].Yposition)
                                         {
                                             if(Y>= users[j].w->breaking_points[t].Yposition && Y<=users[j].w->tail.Yposition)
                                             {
                                                 users[i].w->decrease_lenght();
                                                 X=users[i].w->head.Xposition ;
                                                 Y=users[i].w->head.Yposition ;
                                                 if(users[i].w->breaking_points.size()==0)
                                                 {
                                                     fbx=users[i].w->tail.Xposition;
                                                     fby=users[i].w->tail.Yposition;
                                                 }
                                                 else
                                                 {
                                                     fbx=users[i].w->breaking_points[0].Xposition;
                                                     fby=users[i].w->breaking_points[0].Yposition;
                                                 }
                                             }
                                         }
                                         else
                                         {
                                            if(Y>users[j].w->tail.Yposition && Y<=users[j].w->breaking_points[t].Yposition)
                                            {
                                                users[i].w->decrease_lenght();
                                                X=users[i].w->head.Xposition ;
                                                Y=users[i].w->head.Yposition ;
                                                if(users[i].w->breaking_points.size()==0)
                                                {
                                                    fbx=users[i].w->tail.Xposition;
                                                    fby=users[i].w->tail.Yposition;
                                                }
                                                else
                                                {
                                                    fbx=users[i].w->breaking_points[0].Xposition;
                                                    fby=users[i].w->breaking_points[0].Yposition;
                                                }
                                            }
                                         }
                                     }
                                 }
                              }
                     }
                   }
                   else
                   {
                     if(users[j].w->breaking_points.size()==0)
                         {
                             if(users[j].w->rasta_head == 'h')
                             {
                               if(Y == users[j].w->head.Yposition)
                               {
                                    if(users[j].w->head.Xposition >users[j].w->tail.Xposition)
                                    {
                                        if((X>=users[j].w->tail.Xposition && X<=users[j].w->head.Xposition)||(X<=users[j].w->tail.Xposition && fbx >=users[j].w->head.Xposition))
                                        {
                                            users[i].w->decrease_lenght();
                                            users[j].w->decrease_lenght();
                                            X=users[i].w->head.Xposition ;
                                            Y=users[i].w->head.Yposition ;
                                            if(users[i].w->breaking_points.size()==0)
                                            {
                                                fbx=users[i].w->tail.Xposition;
                                                fby=users[i].w->tail.Yposition;
                                            }
                                            else
                                            {
                                                fbx=users[i].w->breaking_points[0].Xposition;
                                                fby=users[i].w->breaking_points[0].Yposition;
                                            }
                                        }
                                    }
                                    else
                                    {
                                        if((X>=users[j].w->head.Xposition && X<=users[j].w->tail.Xposition)||(X<=users[j].w->head.Xposition && fbx>=users[j].w->tail.Xposition))
                                        {
                                            users[i].w->decrease_lenght();
                                            X=users[i].w->head.Xposition ;
                                            Y=users[i].w->head.Yposition ;
                                            if(users[i].w->breaking_points.size()==0)
                                            {
                                                fbx=users[i].w->tail.Xposition;
                                                fby=users[i].w->tail.Yposition;
                                            }
                                            else
                                            {
                                                fbx=users[i].w->breaking_points[0].Xposition;
                                                fby=users[i].w->breaking_points[0].Yposition;
                                            }
                                        }
                                    }
                               }
                             }
                             else
                             {
                                 if(X<=users[j].w->head.Xposition && fbx >users[j].w->head.Xposition )
                                 {
                                    if(users[j].w->head.Yposition > users[j].w->tail.Yposition )
                                    {
                                        if(Y>=users[j].w->tail.Yposition && Y<=users[j].w->head.Yposition)
                                        {
                                            users[i].w->decrease_lenght();
                                            X=users[i].w->head.Xposition ;
                                            Y=users[i].w->head.Yposition ;
                                            if(users[i].w->breaking_points.size()==0)
                                            {
                                                fbx=users[i].w->tail.Xposition;
                                                fby=users[i].w->tail.Yposition;
                                            }
                                            else
                                            {
                                                fbx=users[i].w->breaking_points[0].Xposition;
                                                fby=users[i].w->breaking_points[0].Yposition;
                                            }
                                        }
                                    }
                                    else
                                    {
                                        if(Y>=users[j].w->head.Yposition && Y<=users[j].w->tail.Yposition )
                                        {
                                            users[i].w->decrease_lenght();
                                            X=users[i].w->head.Xposition ;
                                            Y=users[i].w->head.Yposition ;
                                            if(users[i].w->breaking_points.size()==0)
                                            {
                                                fbx=users[i].w->tail.Xposition;
                                                fby=users[i].w->tail.Yposition;
                                            }
                                            else
                                            {
                                                fbx=users[i].w->breaking_points[0].Xposition;
                                                fby=users[i].w->breaking_points[0].Yposition;
                                            }
                                        }
                                    }
                                 }
                             }
                         }
                     else
                     {
                      if(users[j].w->rasta_head == 'h')
                      {
                        if(users[j].w->breaking_points.size()==1)
                               {
                                   if(users[j].w->tail.Yposition > users[j].w->breaking_points[0].Yposition)
                                   {
                                       if(X<=users[j].w->tail.Xposition && fbx >=users[j].w->tail.Xposition )
                                       {
                                          if(Y == users[j].w->breaking_points[0].Yposition)
                                          {
                                              if(users[j].w->head.Xposition >users[j].w->breaking_points[0].Xposition )
                                              {
                                                  users[i].w->decrease_lenght();
                                                  users[j].w->decrease_lenght();
                                                  X=users[i].w->head.Xposition ;
                                                  Y=users[i].w->head.Yposition ;
                                                  if(users[i].w->breaking_points.size()==0)
                                                  {
                                                      fbx=users[i].w->tail.Xposition;
                                                      fby=users[i].w->tail.Yposition;
                                                  }
                                                  else
                                                  {
                                                      fbx=users[i].w->breaking_points[0].Xposition;
                                                      fby=users[i].w->breaking_points[0].Yposition;
                                                  }
                                              }
                                              else
                                              {
                                                  users[i].w->decrease_lenght();
                                                  X=users[i].w->head.Xposition ;
                                                  Y=users[i].w->head.Yposition ;
                                                  if(users[i].w->breaking_points.size()==0)
                                                  {
                                                      fbx=users[i].w->tail.Xposition;
                                                      fby=users[i].w->tail.Yposition;
                                                  }
                                                  else
                                                  {
                                                      fbx=users[i].w->breaking_points[0].Xposition;
                                                      fby=users[i].w->breaking_points[0].Yposition;
                                                  }

                                              }
                                          }
                                          else
                                          {
                                             if(Y>users[j].w->breaking_points[0].Yposition && Y<=users[j].w->tail.Yposition )
                                             {
                                                 users[i].w->decrease_lenght();
                                                 X=users[i].w->head.Xposition ;
                                                 Y=users[i].w->head.Yposition ;
                                                 if(users[i].w->breaking_points.size()==0)
                                                 {
                                                     fbx=users[i].w->tail.Xposition;
                                                     fby=users[i].w->tail.Yposition;
                                                 }
                                                 else
                                                 {
                                                     fbx=users[i].w->breaking_points[0].Xposition;
                                                     fby=users[i].w->breaking_points[0].Yposition;
                                                 }
                                             }
                                          }
                                       }

                                   }
                                   else
                                   {
                                       if(X<=users[j].w->tail.Xposition && fbx >=users[j].w->tail.Xposition )
                                       {
                                          if(Y == users[j].w->breaking_points[0].Yposition)
                                          {
                                              if(users[j].w->head.Xposition >users[j].w->breaking_points[0].Xposition )
                                              {
                                                  users[i].w->decrease_lenght();
                                                  users[j].w->decrease_lenght();
                                                  X=users[i].w->head.Xposition ;
                                                  Y=users[i].w->head.Yposition ;
                                                  if(users[i].w->breaking_points.size()==0)
                                                  {
                                                      fbx=users[i].w->tail.Xposition;
                                                      fby=users[i].w->tail.Yposition;
                                                  }
                                                  else
                                                  {
                                                      fbx=users[i].w->breaking_points[0].Xposition;
                                                      fby=users[i].w->breaking_points[0].Yposition;
                                                  }
                                              }
                                              else
                                              {
                                                  users[i].w->decrease_lenght();
                                                  X=users[i].w->head.Xposition ;
                                                  Y=users[i].w->head.Yposition ;
                                                  if(users[i].w->breaking_points.size()==0)
                                                  {
                                                      fbx=users[i].w->tail.Xposition;
                                                      fby=users[i].w->tail.Yposition;
                                                  }
                                                  else
                                                  {
                                                      fbx=users[i].w->breaking_points[0].Xposition;
                                                      fby=users[i].w->breaking_points[0].Yposition;
                                                  }

                                              }
                                          }
                                          else
                                          {
                                              if(Y>=users[j].w->tail.Yposition && Y<users[j].w->breaking_points[0].Yposition)
                                              {
                                                  users[i].w->decrease_lenght();
                                                  X=users[i].w->head.Xposition ;
                                                  Y=users[i].w->head.Yposition ;
                                                  if(users[i].w->breaking_points.size()==0)
                                                  {
                                                      fbx=users[i].w->tail.Xposition;
                                                      fby=users[i].w->tail.Yposition;
                                                  }
                                                  else
                                                  {
                                                      fbx=users[i].w->breaking_points[0].Xposition;
                                                      fby=users[i].w->breaking_points[0].Yposition;
                                                  }
                                              }
                                          }
                                       }
                                   }
                               }
                        else
                               {
                                   for(int z=0;z<users[j].w->breaking_points.size()-1;z++)
                                   {
                                       if(users[j].w->breaking_points[z].Xposition == users[j].w->breaking_points[z+1].Xposition )
                                       {
                                         if(X<=users[j].w->breaking_points[z].Xposition && fbx>= users[j].w->breaking_points[z].Xposition)
                                         {
                                             if(z==0)
                                             {
                                              if(Y==users[j].w->breaking_points[0].Yposition)
                                              {
                                                  if(users[j].w->head.Xposition > users[j].w->breaking_points[0].Xposition)
                                                  {
                                                      users[i].w->decrease_lenght();
                                                      users[j].w->decrease_lenght();
                                                      X=users[i].w->head.Xposition ;
                                                      Y=users[i].w->head.Yposition ;
                                                      if(users[i].w->breaking_points.size()==0)
                                                      {
                                                          fbx=users[i].w->tail.Xposition;
                                                          fby=users[i].w->tail.Yposition;
                                                      }
                                                      else
                                                      {
                                                          fbx=users[i].w->breaking_points[0].Xposition;
                                                          fby=users[i].w->breaking_points[0].Yposition;
                                                      }
                                                  }
                                                  else
                                                  {
                                                      users[i].w->decrease_lenght();
                                                      X=users[i].w->head.Xposition ;
                                                      Y=users[i].w->head.Yposition ;
                                                      if(users[i].w->breaking_points.size()==0)
                                                      {
                                                          fbx=users[i].w->tail.Xposition;
                                                          fby=users[i].w->tail.Yposition;
                                                      }
                                                      else
                                                      {
                                                          fbx=users[i].w->breaking_points[0].Xposition;
                                                          fby=users[i].w->breaking_points[0].Yposition;
                                                      }

                                                  }
                                                  continue ;
                                              }
                                             }

                                             if(users[j].w->breaking_points[z].Yposition>users[j].w->breaking_points[z+1].Yposition)
                                             {
                                                 if(Y >=users[j].w->breaking_points[z+1].Yposition && Y<=users[j].w->breaking_points[z].Yposition)
                                                 {
                                                     users[i].w->decrease_lenght();
                                                     X=users[i].w->head.Xposition ;
                                                     Y=users[i].w->head.Yposition ;
                                                     if(users[i].w->breaking_points.size()==0)
                                                     {
                                                         fbx=users[i].w->tail.Xposition;
                                                         fby=users[i].w->tail.Yposition;
                                                     }
                                                     else
                                                     {
                                                         fbx=users[i].w->breaking_points[0].Xposition;
                                                         fby=users[i].w->breaking_points[0].Yposition;
                                                     }
                                                 }

                                             }
                                             else
                                             {
                                                 if(Y>=users[j].w->breaking_points[z].Yposition && Y<=users[j].w->breaking_points[z+1].Yposition)
                                                 {
                                                    users[i].w->decrease_lenght();
                                                    X=users[i].w->head.Xposition ;
                                                    Y=users[i].w->head.Yposition ;
                                                    if(users[i].w->breaking_points.size()==0)
                                                    {
                                                        fbx=users[i].w->tail.Xposition;
                                                        fby=users[i].w->tail.Yposition;
                                                    }
                                                    else
                                                    {
                                                        fbx=users[i].w->breaking_points[0].Xposition;
                                                        fby=users[i].w->breaking_points[0].Yposition;
                                                    }
                                                 }
                                             }

                                        }
                                      }

                                   }
                                   if(users[j].w->rasta_tail == 'v')
                                   {
                                       if(X<= users[j].w->tail.Xposition && fbx >= users[j].w->tail.Xposition)
                                       {
                                           int t=users[j].w->breaking_points.size()-1;
                                           if(users[j].w->tail.Yposition > users[j].w->breaking_points[t].Yposition )
                                           {
                                               if(Y >= users[j].w->breaking_points[t].Yposition && Y <=users[j].w->tail.Yposition  )
                                               {
                                                 users[i].w->decrease_lenght();
                                                 X=users[i].w->head.Xposition ;
                                                 Y=users[i].w->head.Yposition ;
                                                 if(users[i].w->breaking_points.size()==0)
                                                 {
                                                     fbx=users[i].w->tail.Xposition;
                                                     fby=users[i].w->tail.Yposition;
                                                 }
                                                 else
                                                 {
                                                     fbx=users[i].w->breaking_points[0].Xposition;
                                                     fby=users[i].w->breaking_points[0].Yposition;
                                                 }
                                               }
                                           }
                                           else
                                           {
                                               if(Y>=users[j].w->tail.Yposition && Y <= users[j].w->breaking_points[t].Yposition)
                                               {
                                                  users[i].w->decrease_lenght();
                                                  X=users[i].w->head.Xposition ;
                                                  Y=users[i].w->head.Yposition ;
                                                  if(users[i].w->breaking_points.size()==0)
                                                  {
                                                      fbx=users[i].w->tail.Xposition;
                                                      fby=users[i].w->tail.Yposition;
                                                  }
                                                  else
                                                  {
                                                      fbx=users[i].w->breaking_points[0].Xposition;
                                                      fby=users[i].w->breaking_points[0].Yposition;
                                                  }
                                               }
                                           }
                                       }
                                   }
                               }
                      }
                      else
                           {
                               if(X<= users[j].w->head.Xposition && fbx >= users[j].w->head.Xposition)
                               {
                                   if(users[j].w->head.Yposition > users[j].w->breaking_points[0].Yposition)
                                   {
                                       if(Y>=users[j].w->breaking_points[0].Yposition && Y<=users[j].w->head.Yposition)
                                       {
                                           users[i].w->decrease_lenght();
                                           X=users[i].w->head.Xposition ;
                                           Y=users[i].w->head.Yposition ;
                                           if(users[i].w->breaking_points.size()==0)
                                           {
                                               fbx=users[i].w->tail.Xposition;
                                               fby=users[i].w->tail.Yposition;
                                           }
                                           else
                                           {
                                               fbx=users[i].w->breaking_points[0].Xposition;
                                               fby=users[i].w->breaking_points[0].Yposition;
                                           }

                                       }
                                   }
                                   else
                                   {
                                       if(Y>=users[j].w->head.Yposition && Y<=users[j].w->breaking_points[0].Yposition)
                                       {
                                           users[i].w->decrease_lenght();
                                           X=users[i].w->head.Xposition ;
                                           Y=users[i].w->head.Yposition ;
                                           if(users[i].w->breaking_points.size()==0)
                                           {
                                               fbx=users[i].w->tail.Xposition;
                                               fby=users[i].w->tail.Yposition;
                                           }
                                           else
                                           {
                                               fbx=users[i].w->breaking_points[0].Xposition;
                                               fby=users[i].w->breaking_points[0].Yposition;
                                           }
                                       }
                                   }
                               }
                               for(int z=0;z<users[j].w->breaking_points.size()-1;z++)
                               {
                                   if(users[j].w->breaking_points[z].Xposition==users[j].w->breaking_points[z+1].Xposition)
                                   {
                                       if(X<=users[j].w->breaking_points[z].Xposition && fbx>=users[j].w->breaking_points[z].Xposition)
                                       {
                                           if(users[j].w->breaking_points[z].Yposition >users[j].w->breaking_points[z+1].Yposition)
                                           {
                                               if(Y>=users[j].w->breaking_points[z+1].Yposition && Y<=users[j].w->breaking_points[z].Yposition)
                                               {
                                                   users[i].w->decrease_lenght();
                                                   X=users[i].w->head.Xposition ;
                                                   Y=users[i].w->head.Yposition ;
                                                   if(users[i].w->breaking_points.size()==0)
                                                   {
                                                       fbx=users[i].w->tail.Xposition;
                                                       fby=users[i].w->tail.Yposition;
                                                   }
                                                   else
                                                   {
                                                       fbx=users[i].w->breaking_points[0].Xposition;
                                                       fby=users[i].w->breaking_points[0].Yposition;
                                                   }
                                               }
                                           }
                                           else
                                           {
                                               if(Y>=users[j].w->breaking_points[z].Yposition && Y<=users[j].w->breaking_points[z+1].Yposition)
                                               {
                                                   users[i].w->decrease_lenght();
                                                   X=users[i].w->head.Xposition ;
                                                   Y=users[i].w->head.Yposition ;
                                                   if(users[i].w->breaking_points.size()==0)
                                                   {
                                                       fbx=users[i].w->tail.Xposition;
                                                       fby=users[i].w->tail.Yposition;
                                                   }
                                                   else
                                                   {
                                                       fbx=users[i].w->breaking_points[0].Xposition;
                                                       fby=users[i].w->breaking_points[0].Yposition;
                                                   }
                                               }
                                           }
                                       }
                                   }
                               }
                               if(users[j].w->rasta_tail=='v')
                               {
                                   int t=users[j].w->breaking_points.size()-1;
                                   if(X<=users[j].w->tail.Xposition && fbx>=users[j].w->tail.Xposition)
                                   {
                                       if(users[j].w->tail.Yposition > users[j].w->breaking_points[t].Yposition)
                                       {
                                           if(Y>= users[j].w->breaking_points[t].Yposition && Y<=users[j].w->tail.Yposition)
                                           {
                                               users[i].w->decrease_lenght();
                                               X=users[i].w->head.Xposition ;
                                               Y=users[i].w->head.Yposition ;
                                               if(users[i].w->breaking_points.size()==0)
                                               {
                                                   fbx=users[i].w->tail.Xposition;
                                                   fby=users[i].w->tail.Yposition;
                                               }
                                               else
                                               {
                                                   fbx=users[i].w->breaking_points[0].Xposition;
                                                   fby=users[i].w->breaking_points[0].Yposition;
                                               }
                                           }
                                       }
                                       else
                                       {
                                          if(Y>users[j].w->tail.Yposition && Y<=users[j].w->breaking_points[t].Yposition)
                                          {
                                              users[i].w->decrease_lenght();
                                              X=users[i].w->head.Xposition ;
                                              Y=users[i].w->head.Yposition ;
                                              if(users[i].w->breaking_points.size()==0)
                                              {
                                                  fbx=users[i].w->tail.Xposition;
                                                  fby=users[i].w->tail.Yposition;
                                              }
                                              else
                                              {
                                                  fbx=users[i].w->breaking_points[0].Xposition;
                                                  fby=users[i].w->breaking_points[0].Yposition;
                                              }
                                          }
                                       }
                                   }
                               }
                           }
                     }
                   }
                }
                else
                {
                   if(Y>fby)
                   {
                     if(users[j].w->breaking_points.size()==0)
                     {
                         if(users[j].w->rasta_head =='h')
                         {
                             if(Y>=users[j].w->head.Yposition && fby<=users[j].w->head.Yposition )
                             {
                                 if(users[j].w->head.Xposition > users[j].w->tail.Xposition)
                                 {
                                     if(X>=users[j].w->tail.Xposition && X<=users[j].w->head.Xposition)
                                     {
                                         users[i].w->decrease_lenght();
                                         X=users[i].w->head.Xposition ;
                                         Y=users[i].w->head.Yposition ;
                                         if(users[i].w->breaking_points.size()==0)
                                         {
                                             fbx=users[i].w->tail.Xposition;
                                             fby=users[i].w->tail.Yposition;
                                         }
                                         else
                                         {
                                             fbx=users[i].w->breaking_points[0].Xposition;
                                             fby=users[i].w->breaking_points[0].Yposition;
                                         }
                                     }
                                 }
                                 else
                                 {
                                     if(X>=users[j].w->head.Xposition && X<=users[j].w->tail.Xposition)
                                     {
                                         users[i].w->decrease_lenght();
                                         X=users[i].w->head.Xposition ;
                                         Y=users[i].w->head.Yposition ;
                                         if(users[i].w->breaking_points.size()==0)
                                         {
                                             fbx=users[i].w->tail.Xposition;
                                             fby=users[i].w->tail.Yposition;
                                         }
                                         else
                                         {
                                             fbx=users[i].w->breaking_points[0].Xposition;
                                             fby=users[i].w->breaking_points[0].Yposition;
                                         }
                                     }
                                 }
                             }
                         }
                         else
                         {
                             if(X==users[j].w->head.Xposition)
                             {
                                 if(users[j].w->head.Yposition > users[j].w->tail.Yposition )
                                 {
                                     if((Y>=users[j].w->tail.Yposition && Y<= users[j].w->head.Yposition ) || (Y>=users[j].w->head.Yposition && fby<=users[j].w->tail.Yposition))
                                     {
                                         users[i].w->decrease_lenght();
                                         X=users[i].w->head.Xposition ;
                                         Y=users[i].w->head.Yposition ;
                                         if(users[i].w->breaking_points.size()==0)
                                         {
                                             fbx=users[i].w->tail.Xposition;
                                             fby=users[i].w->tail.Yposition;
                                         }
                                         else
                                         {
                                             fbx=users[i].w->breaking_points[0].Xposition;
                                             fby=users[i].w->breaking_points[0].Yposition;
                                         }
                                     }
                                 }
                                 else
                                 {
                                    if((Y>=users[j].w->head.Yposition && Y<=users[j].w->tail.Yposition)|| (Y>=users[j].w->tail.Yposition && fby<=users[j].w->head.Yposition))
                                    {
                                        users[i].w->decrease_lenght();
                                        users[j].w->decrease_lenght();
                                        X=users[i].w->head.Xposition ;
                                        Y=users[i].w->head.Yposition ;
                                        if(users[i].w->breaking_points.size()==0)
                                        {
                                            fbx=users[i].w->tail.Xposition;
                                            fby=users[i].w->tail.Yposition;
                                        }
                                        else
                                        {
                                            fbx=users[i].w->breaking_points[0].Xposition;
                                            fby=users[i].w->breaking_points[0].Yposition;
                                        }
                                    }
                                 }
                             }
                         }
                     }
                     else
                     {
                         if(users[j].w->rasta_head == 'h')
                         {
                             if(Y>=users[j].w->head.Yposition && fby <=users[j].w->head.Yposition )
                             {
                                 if(users[j].w->head.Xposition > users[j].w->breaking_points[0].Xposition)
                                 {
                                     if(X>=users[j].w->breaking_points[0].Xposition && X<=users[j].w->head.Xposition)
                                     {
                                         users[i].w->decrease_lenght();
                                         X=users[i].w->head.Xposition ;
                                         Y=users[i].w->head.Yposition ;
                                         if(users[i].w->breaking_points.size()==0)
                                         {
                                             fbx=users[i].w->tail.Xposition;
                                             fby=users[i].w->tail.Yposition;
                                         }
                                         else
                                         {
                                             fbx=users[i].w->breaking_points[0].Xposition;
                                             fby=users[i].w->breaking_points[0].Yposition;
                                         }
                                     }
                                 }
                                 else
                                 {
                                     if(X>=users[j].w->head.Xposition && X<=users[j].w->breaking_points[0].Xposition)
                                     {
                                         users[i].w->decrease_lenght();
                                         X=users[i].w->head.Xposition ;
                                         Y=users[i].w->head.Yposition ;
                                         if(users[i].w->breaking_points.size()==0)
                                         {
                                             fbx=users[i].w->tail.Xposition;
                                             fby=users[i].w->tail.Yposition;
                                         }
                                         else
                                         {
                                             fbx=users[i].w->breaking_points[0].Xposition;
                                             fby=users[i].w->breaking_points[0].Yposition;
                                         }
                                     }
                                 }
                             }
                             for(int z=0;z<users[j].w->breaking_points.size()-1;z++)
                             {
                                 if(users[j].w->breaking_points[z].Yposition == users[j].w->breaking_points[z+1].Yposition )
                                 {
                                     if(Y>=users[j].w->breaking_points[z].Yposition && fby<= users[j].w->breaking_points[z].Yposition)
                                     {
                                         if(users[j].w->breaking_points[z].Xposition > users[j].w->breaking_points[z+1].Xposition)
                                         {
                                             if(X>=users[j].w->breaking_points[z+1].Xposition && X<=users[j].w->breaking_points[z].Xposition )
                                             {
                                                 users[i].w->decrease_lenght();
                                                 X=users[i].w->head.Xposition ;
                                                 Y=users[i].w->head.Yposition ;
                                                 if(users[i].w->breaking_points.size()==0)
                                                 {
                                                     fbx=users[i].w->tail.Xposition;
                                                     fby=users[i].w->tail.Yposition;
                                                 }
                                                 else
                                                 {
                                                     fbx=users[i].w->breaking_points[0].Xposition;
                                                     fby=users[i].w->breaking_points[0].Yposition;
                                                 }
                                             }
                                         }
                                         else
                                         {
                                             if(X>=users[j].w->breaking_points[z].Xposition && X<= users[j].w->breaking_points[z+1].Xposition)
                                             {
                                                 users[i].w->decrease_lenght();
                                                 X=users[i].w->head.Xposition ;
                                                 Y=users[i].w->head.Yposition ;
                                                 if(users[i].w->breaking_points.size()==0)
                                                 {
                                                     fbx=users[i].w->tail.Xposition;
                                                     fby=users[i].w->tail.Yposition;
                                                 }
                                                 else
                                                 {
                                                     fbx=users[i].w->breaking_points[0].Xposition;
                                                     fby=users[i].w->breaking_points[0].Yposition;
                                                 }
                                             }
                                         }
                                     }
                                 }
                             }
                             if(users[j].w->rasta_tail== 'h')
                             {
                                 if(Y>= users[j].w->tail.Yposition && fby <= users[j].w->tail.Yposition)
                                 {
                                     int t=users[j].w->breaking_points.size()-1;
                                     if(users[j].w->tail.Xposition > users[j].w->breaking_points[t].Xposition)
                                     {
                                         if(X>=users[j].w->breaking_points[t].Xposition && X<=users[j].w->tail.Xposition )
                                         {
                                             users[i].w->decrease_lenght();
                                             X=users[i].w->head.Xposition ;
                                             Y=users[i].w->head.Yposition ;
                                             if(users[i].w->breaking_points.size()==0)
                                             {
                                                 fbx=users[i].w->tail.Xposition;
                                                 fby=users[i].w->tail.Yposition;
                                             }
                                             else
                                             {
                                                 fbx=users[i].w->breaking_points[0].Xposition;
                                                 fby=users[i].w->breaking_points[0].Yposition;
                                             }
                                         }
                                     }
                                     else
                                     {
                                         if(X>=users[j].w->tail.Xposition && X<= users[j].w->breaking_points[t].Xposition)
                                         {
                                             users[i].w->decrease_lenght();
                                             X=users[i].w->head.Xposition ;
                                             Y=users[i].w->head.Yposition ;
                                             if(users[i].w->breaking_points.size()==0)
                                             {
                                                 fbx=users[i].w->tail.Xposition;
                                                 fby=users[i].w->tail.Yposition;
                                             }
                                             else
                                             {
                                                 fbx=users[i].w->breaking_points[0].Xposition;
                                                 fby=users[i].w->breaking_points[0].Yposition;
                                             }
                                         }
                                     }
                                 }
                             }
                         }
                         else
                         {
                             if(users[j].w->breaking_points.size()==1)
                             {
                                if(users[j].w->tail.Xposition > users[j].w->breaking_points[0].Xposition)
                                {
                                   if(Y>=users[j].w->breaking_points[0].Yposition && fby<=users[j].w->breaking_points[0].Yposition)
                                   {
                                    if(X==users[j].w->breaking_points[0].Xposition)
                                    {
                                       if(users[j].w->head.Yposition > users[j].w->breaking_points[0].Yposition)
                                       {
                                           users[i].w->decrease_lenght();
                                           X=users[i].w->head.Xposition ;
                                           Y=users[i].w->head.Yposition ;
                                           if(users[i].w->breaking_points.size()==0)
                                           {
                                               fbx=users[i].w->tail.Xposition;
                                               fby=users[i].w->tail.Yposition;
                                           }
                                           else
                                           {
                                               fbx=users[i].w->breaking_points[0].Xposition;
                                               fby=users[i].w->breaking_points[0].Yposition;
                                           }
                                       }
                                       else
                                       {
                                           users[i].w->decrease_lenght();
                                           users[j].w->decrease_lenght();
                                           X=users[i].w->head.Xposition ;
                                           Y=users[i].w->head.Yposition ;
                                           if(users[i].w->breaking_points.size()==0)
                                           {
                                               fbx=users[i].w->tail.Xposition;
                                               fby=users[i].w->tail.Yposition;
                                           }
                                           else
                                           {
                                               fbx=users[i].w->breaking_points[0].Xposition;
                                               fby=users[i].w->breaking_points[0].Yposition;
                                           }
                                       }
                                    }
                                    else
                                    {
                                       if(X>users[j].w->breaking_points[0].Xposition && X<=users[j].w->tail.Xposition)
                                       {
                                           users[i].w->decrease_lenght();
                                           X=users[i].w->head.Xposition ;
                                           Y=users[i].w->head.Yposition ;
                                           if(users[i].w->breaking_points.size()==0)
                                           {
                                               fbx=users[i].w->tail.Xposition;
                                               fby=users[i].w->tail.Yposition;
                                           }
                                           else
                                           {
                                               fbx=users[i].w->breaking_points[0].Xposition;
                                               fby=users[i].w->breaking_points[0].Yposition;
                                           }
                                       }
                                    }
                                   }
                                }
                                else
                                {
                                    if(Y>=users[j].w->breaking_points[0].Yposition && fby<=users[j].w->breaking_points[0].Yposition)
                                    {
                                     if(X==users[j].w->breaking_points[0].Xposition)
                                     {
                                        if(users[j].w->head.Yposition > users[j].w->breaking_points[0].Yposition)
                                        {
                                            users[i].w->decrease_lenght();
                                            X=users[i].w->head.Xposition ;
                                            Y=users[i].w->head.Yposition ;
                                            if(users[i].w->breaking_points.size()==0)
                                            {
                                                fbx=users[i].w->tail.Xposition;
                                                fby=users[i].w->tail.Yposition;
                                            }
                                            else
                                            {
                                                fbx=users[i].w->breaking_points[0].Xposition;
                                                fby=users[i].w->breaking_points[0].Yposition;
                                            }
                                        }
                                        else
                                        {
                                            users[i].w->decrease_lenght();
                                            users[j].w->decrease_lenght();
                                            X=users[i].w->head.Xposition ;
                                            Y=users[i].w->head.Yposition ;
                                            if(users[i].w->breaking_points.size()==0)
                                            {
                                                fbx=users[i].w->tail.Xposition;
                                                fby=users[i].w->tail.Yposition;
                                            }
                                            else
                                            {
                                                fbx=users[i].w->breaking_points[0].Xposition;
                                                fby=users[i].w->breaking_points[0].Yposition;
                                            }
                                        }
                                     }
                                     else
                                     {
                                        if(X<users[j].w->breaking_points[0].Xposition && X>=users[j].w->tail.Xposition)
                                        {
                                            users[i].w->decrease_lenght();
                                            X=users[i].w->head.Xposition ;
                                            Y=users[i].w->head.Yposition ;
                                            if(users[i].w->breaking_points.size()==0)
                                            {
                                                fbx=users[i].w->tail.Xposition;
                                                fby=users[i].w->tail.Yposition;
                                            }
                                            else
                                            {
                                                fbx=users[i].w->breaking_points[0].Xposition;
                                                fby=users[i].w->breaking_points[0].Yposition;
                                            }
                                        }
                                     }
                                    }
                                }
                             }
                             else
                             {
                                for(int z=0 ;z<users[j].w->breaking_points.size()-1;z++)
                                {
                                  if(users[j].w->breaking_points[z].Yposition == users[j].w->breaking_points[z+1].Yposition)
                                  {
                                     if(Y>=users[j].w->breaking_points[z].Yposition && fby <=users[j].w->breaking_points[z].Yposition )
                                     {
                                         if(z==0)
                                         {
                                             if(X==users[j].w->breaking_points[0].Xposition)
                                             {
                                                if(users[j].w->head.Yposition > users[j].w->breaking_points[0].Yposition)
                                                {
                                                    users[i].w->decrease_lenght();
                                                    X=users[i].w->head.Xposition ;
                                                    Y=users[i].w->head.Yposition ;
                                                    if(users[i].w->breaking_points.size()==0)
                                                    {
                                                        fbx=users[i].w->tail.Xposition;
                                                        fby=users[i].w->tail.Yposition;
                                                    }
                                                    else
                                                    {
                                                        fbx=users[i].w->breaking_points[0].Xposition;
                                                        fby=users[i].w->breaking_points[0].Yposition;
                                                    }
                                                }
                                                else
                                                {
                                                    users[i].w->decrease_lenght();
                                                    users[j].w->decrease_lenght();
                                                    X=users[i].w->head.Xposition ;
                                                    Y=users[i].w->head.Yposition ;
                                                    if(users[i].w->breaking_points.size()==0)
                                                    {
                                                        fbx=users[i].w->tail.Xposition;
                                                        fby=users[i].w->tail.Yposition;
                                                    }
                                                    else
                                                    {
                                                        fbx=users[i].w->breaking_points[0].Xposition;
                                                        fby=users[i].w->breaking_points[0].Yposition;
                                                    }
                                                }
                                                continue;
                                             }
                                         }
                                         if(users[j].w->breaking_points[z].Xposition >users[j].w->breaking_points[z+1].Xposition )
                                         {
                                            if(X>=users[j].w->breaking_points[z+1].Xposition && X<=users[j].w->breaking_points[z].Xposition )
                                            {
                                                users[i].w->decrease_lenght();
                                                X=users[i].w->head.Xposition ;
                                                Y=users[i].w->head.Yposition ;
                                                if(users[i].w->breaking_points.size()==0)
                                                {
                                                    fbx=users[i].w->tail.Xposition;
                                                    fby=users[i].w->tail.Yposition;
                                                }
                                                else
                                                {
                                                    fbx=users[i].w->breaking_points[0].Xposition;
                                                    fby=users[i].w->breaking_points[0].Yposition;
                                                }
                                            }
                                         }
                                         else
                                         {
                                             if(X>=users[j].w->breaking_points[z].Xposition && X<=users[j].w->breaking_points[z+1].Xposition)
                                             {
                                                 users[i].w->decrease_lenght();
                                                 X=users[i].w->head.Xposition ;
                                                 Y=users[i].w->head.Yposition ;
                                                 if(users[i].w->breaking_points.size()==0)
                                                 {
                                                     fbx=users[i].w->tail.Xposition;
                                                     fby=users[i].w->tail.Yposition;
                                                 }
                                                 else
                                                 {
                                                     fbx=users[i].w->breaking_points[0].Xposition;
                                                     fby=users[i].w->breaking_points[0].Yposition;
                                                 }
                                             }
                                         }
                                     }
                                  }
                                }
                                if(users[j].w->rasta_tail== 'h')
                                {
                                   int t =users[j].w->breaking_points.size()-1 ;
                                   if(Y>=users[j].w->tail.Yposition && fby <= users[j].w->tail.Yposition)
                                   {
                                       if(users[j].w->tail.Xposition >users[j].w->breaking_points[t].Xposition )
                                       {
                                          if(X>=users[j].w->breaking_points[t].Xposition && X<=users[j].w->tail.Xposition)
                                          {
                                              users[i].w->decrease_lenght();
                                              X=users[i].w->head.Xposition ;
                                              Y=users[i].w->head.Yposition ;
                                              if(users[i].w->breaking_points.size()==0)
                                              {
                                                  fbx=users[i].w->tail.Xposition;
                                                  fby=users[i].w->tail.Yposition;
                                              }
                                              else
                                              {
                                                  fbx=users[i].w->breaking_points[0].Xposition;
                                                  fby=users[i].w->breaking_points[0].Yposition;
                                              }
                                          }
                                       }
                                       else
                                       {
                                          if(X>=users[j].w->tail.Xposition && X<=users[j].w->breaking_points[t].Xposition)
                                          {
                                              users[i].w->decrease_lenght();
                                              X=users[i].w->head.Xposition ;
                                              Y=users[i].w->head.Yposition ;
                                              if(users[i].w->breaking_points.size()==0)
                                              {
                                                  fbx=users[i].w->tail.Xposition;
                                                  fby=users[i].w->tail.Yposition;
                                              }
                                              else
                                              {
                                                  fbx=users[i].w->breaking_points[0].Xposition;
                                                  fby=users[i].w->breaking_points[0].Yposition;
                                              }
                                          }
                                       }
                                   }
                                }

                             }
                         }
                     }
                   }
                   else
                   {
                     if(users[j].w->breaking_points.size()==0)
                     {
                         if(users[j].w->rasta_head =='h')
                         {
                             if(Y<=users[j].w->head.Yposition && fby>=users[j].w->head.Yposition )
                             {
                                 if(users[j].w->head.Xposition > users[j].w->tail.Xposition)
                                 {
                                     if(X>=users[j].w->tail.Xposition && X<=users[j].w->head.Xposition)
                                     {
                                         users[i].w->decrease_lenght();
                                         X=users[i].w->head.Xposition ;
                                         Y=users[i].w->head.Yposition ;
                                         if(users[i].w->breaking_points.size()==0)
                                         {
                                             fbx=users[i].w->tail.Xposition;
                                             fby=users[i].w->tail.Yposition;
                                         }
                                         else
                                         {
                                             fbx=users[i].w->breaking_points[0].Xposition;
                                             fby=users[i].w->breaking_points[0].Yposition;
                                         }
                                     }
                                 }
                                 else
                                 {
                                     if(X>=users[j].w->head.Xposition && X<=users[j].w->tail.Xposition)
                                     {
                                         users[i].w->decrease_lenght();
                                         X=users[i].w->head.Xposition ;
                                         Y=users[i].w->head.Yposition ;
                                         if(users[i].w->breaking_points.size()==0)
                                         {
                                             fbx=users[i].w->tail.Xposition;
                                             fby=users[i].w->tail.Yposition;
                                         }
                                         else
                                         {
                                             fbx=users[i].w->breaking_points[0].Xposition;
                                             fby=users[i].w->breaking_points[0].Yposition;
                                         }
                                     }
                                 }
                             }
                         }
                         else
                         {
                             if(X==users[j].w->head.Xposition)
                             {
                                 if(users[j].w->head.Yposition > users[j].w->tail.Yposition )
                                 {
                                     if((Y>=users[j].w->tail.Yposition && Y<= users[j].w->head.Yposition ) || (Y<=users[j].w->tail.Yposition && fby>=users[j].w->head.Yposition))
                                     {
                                         users[i].w->decrease_lenght();
                                         users[j].w->decrease_lenght();
                                         X=users[i].w->head.Xposition ;
                                         Y=users[i].w->head.Yposition ;
                                         if(users[i].w->breaking_points.size()==0)
                                         {
                                             fbx=users[i].w->tail.Xposition;
                                             fby=users[i].w->tail.Yposition;
                                         }
                                         else
                                         {
                                             fbx=users[i].w->breaking_points[0].Xposition;
                                             fby=users[i].w->breaking_points[0].Yposition;
                                         }
                                     }
                                 }
                                 else
                                 {
                                    if((Y>=users[j].w->head.Yposition && Y<=users[j].w->tail.Yposition)|| (Y<=users[j].w->head.Yposition && fby>=users[j].w->tail.Yposition))
                                    {
                                        users[i].w->decrease_lenght();

                                        X=users[i].w->head.Xposition ;
                                        Y=users[i].w->head.Yposition ;
                                        if(users[i].w->breaking_points.size()==0)
                                        {
                                            fbx=users[i].w->tail.Xposition;
                                            fby=users[i].w->tail.Yposition;
                                        }
                                        else
                                        {
                                            fbx=users[i].w->breaking_points[0].Xposition;
                                            fby=users[i].w->breaking_points[0].Yposition;
                                        }
                                    }
                                 }
                             }
                         }
                     }
                     else
                     {
                        if(users[j].w->rasta_head == 'h')
                        {
                            if(Y<=users[j].w->head.Yposition && fby >=users[j].w->head.Yposition )
                            {
                                if(users[j].w->head.Xposition > users[j].w->breaking_points[0].Xposition)
                                {
                                    if(X>=users[j].w->breaking_points[0].Xposition && X<=users[j].w->head.Xposition)
                                    {
                                        users[i].w->decrease_lenght();
                                        X=users[i].w->head.Xposition ;
                                        Y=users[i].w->head.Yposition ;
                                        if(users[i].w->breaking_points.size()==0)
                                        {
                                            fbx=users[i].w->tail.Xposition;
                                            fby=users[i].w->tail.Yposition;
                                        }
                                        else
                                        {
                                            fbx=users[i].w->breaking_points[0].Xposition;
                                            fby=users[i].w->breaking_points[0].Yposition;
                                        }
                                    }
                                }
                                else
                                {
                                    if(X>=users[j].w->head.Xposition && X<=users[j].w->breaking_points[0].Xposition)
                                    {
                                        users[i].w->decrease_lenght();
                                        X=users[i].w->head.Xposition ;
                                        Y=users[i].w->head.Yposition ;
                                        if(users[i].w->breaking_points.size()==0)
                                        {
                                            fbx=users[i].w->tail.Xposition;
                                            fby=users[i].w->tail.Yposition;
                                        }
                                        else
                                        {
                                            fbx=users[i].w->breaking_points[0].Xposition;
                                            fby=users[i].w->breaking_points[0].Yposition;
                                        }
                                    }
                                }
                            }
                            for(int z=0;z<users[j].w->breaking_points.size()-1;z++)
                            {
                                if(users[j].w->breaking_points[z].Yposition == users[j].w->breaking_points[z+1].Yposition )
                                {
                                    if(Y<=users[j].w->breaking_points[z].Yposition && fby>= users[j].w->breaking_points[z].Yposition)
                                    {
                                        if(users[j].w->breaking_points[z].Xposition > users[j].w->breaking_points[z+1].Xposition)
                                        {
                                            if(X>=users[j].w->breaking_points[z+1].Xposition && X<=users[j].w->breaking_points[z].Xposition )
                                            {
                                                users[i].w->decrease_lenght();
                                                X=users[i].w->head.Xposition ;
                                                Y=users[i].w->head.Yposition ;
                                                if(users[i].w->breaking_points.size()==0)
                                                {
                                                    fbx=users[i].w->tail.Xposition;
                                                    fby=users[i].w->tail.Yposition;
                                                }
                                                else
                                                {
                                                    fbx=users[i].w->breaking_points[0].Xposition;
                                                    fby=users[i].w->breaking_points[0].Yposition;
                                                }
                                            }
                                        }
                                        else
                                        {
                                            if(X>=users[j].w->breaking_points[z].Xposition && X<= users[j].w->breaking_points[z+1].Xposition)
                                            {
                                                users[i].w->decrease_lenght();
                                                X=users[i].w->head.Xposition ;
                                                Y=users[i].w->head.Yposition ;
                                                if(users[i].w->breaking_points.size()==0)
                                                {
                                                    fbx=users[i].w->tail.Xposition;
                                                    fby=users[i].w->tail.Yposition;
                                                }
                                                else
                                                {
                                                    fbx=users[i].w->breaking_points[0].Xposition;
                                                    fby=users[i].w->breaking_points[0].Yposition;
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                            if(users[j].w->rasta_tail== 'h')
                            {
                                if(Y<= users[j].w->tail.Yposition && fby >= users[j].w->tail.Yposition)
                                {
                                    int t=users[j].w->breaking_points.size()-1;
                                    if(users[j].w->tail.Xposition > users[j].w->breaking_points[t].Xposition)
                                    {
                                        if(X>=users[j].w->breaking_points[t].Xposition && X<=users[j].w->tail.Xposition )
                                        {
                                            users[i].w->decrease_lenght();
                                            X=users[i].w->head.Xposition ;
                                            Y=users[i].w->head.Yposition ;
                                            if(users[i].w->breaking_points.size()==0)
                                            {
                                                fbx=users[i].w->tail.Xposition;
                                                fby=users[i].w->tail.Yposition;
                                            }
                                            else
                                            {
                                                fbx=users[i].w->breaking_points[0].Xposition;
                                                fby=users[i].w->breaking_points[0].Yposition;
                                            }
                                        }
                                    }
                                    else
                                    {
                                        if(X>=users[j].w->tail.Xposition && X<= users[j].w->breaking_points[t].Xposition)
                                        {
                                            users[i].w->decrease_lenght();
                                            X=users[i].w->head.Xposition ;
                                            Y=users[i].w->head.Yposition ;
                                            if(users[i].w->breaking_points.size()==0)
                                            {
                                                fbx=users[i].w->tail.Xposition;
                                                fby=users[i].w->tail.Yposition;
                                            }
                                            else
                                            {
                                                fbx=users[i].w->breaking_points[0].Xposition;
                                                fby=users[i].w->breaking_points[0].Yposition;
                                            }
                                        }
                                    }
                                }
                            }
                        }
                        else
                        {
                           if(users[j].w->breaking_points.size()==1)
                           {
                               if(users[j].w->tail.Xposition > users[j].w->breaking_points[0].Xposition)
                               {
                                   if(Y<=users[j].w->breaking_points[0].Yposition && fby>=users[j].w->breaking_points[0].Yposition)
                                   {
                                    if(X==users[j].w->breaking_points[0].Xposition)
                                    {
                                       if(users[j].w->head.Yposition > users[j].w->breaking_points[0].Yposition)
                                       {
                                           users[i].w->decrease_lenght();
                                           users[j].w->decrease_lenght();
                                           X=users[i].w->head.Xposition ;
                                           Y=users[i].w->head.Yposition ;
                                           if(users[i].w->breaking_points.size()==0)
                                           {
                                               fbx=users[i].w->tail.Xposition;
                                               fby=users[i].w->tail.Yposition;
                                           }
                                           else
                                           {
                                               fbx=users[i].w->breaking_points[0].Xposition;
                                               fby=users[i].w->breaking_points[0].Yposition;
                                           }
                                       }
                                       else
                                       {
                                           users[i].w->decrease_lenght();

                                           X=users[i].w->head.Xposition ;
                                           Y=users[i].w->head.Yposition ;
                                           if(users[i].w->breaking_points.size()==0)
                                           {
                                               fbx=users[i].w->tail.Xposition;
                                               fby=users[i].w->tail.Yposition;
                                           }
                                           else
                                           {
                                               fbx=users[i].w->breaking_points[0].Xposition;
                                               fby=users[i].w->breaking_points[0].Yposition;
                                           }
                                       }
                                    }
                                    else
                                    {
                                       if(X>users[j].w->breaking_points[0].Xposition && X<=users[j].w->tail.Xposition)
                                       {
                                           users[i].w->decrease_lenght();
                                           X=users[i].w->head.Xposition ;
                                           Y=users[i].w->head.Yposition ;
                                           if(users[i].w->breaking_points.size()==0)
                                           {
                                               fbx=users[i].w->tail.Xposition;
                                               fby=users[i].w->tail.Yposition;
                                           }
                                           else
                                           {
                                               fbx=users[i].w->breaking_points[0].Xposition;
                                               fby=users[i].w->breaking_points[0].Yposition;
                                           }
                                       }
                                    }
                                   }
                               }
                               else
                               {
                                   if(Y<=users[j].w->breaking_points[0].Yposition && fby>=users[j].w->breaking_points[0].Yposition)
                                   {
                                    if(X==users[j].w->breaking_points[0].Xposition)
                                    {
                                       if(users[j].w->head.Yposition > users[j].w->breaking_points[0].Yposition)
                                       {
                                           users[i].w->decrease_lenght();
                                           users[j].w->decrease_lenght();
                                           X=users[i].w->head.Xposition ;
                                           Y=users[i].w->head.Yposition ;
                                           if(users[i].w->breaking_points.size()==0)
                                           {
                                               fbx=users[i].w->tail.Xposition;
                                               fby=users[i].w->tail.Yposition;
                                           }
                                           else
                                           {
                                               fbx=users[i].w->breaking_points[0].Xposition;
                                               fby=users[i].w->breaking_points[0].Yposition;
                                           }
                                       }
                                       else
                                       {
                                           users[i].w->decrease_lenght();

                                           X=users[i].w->head.Xposition ;
                                           Y=users[i].w->head.Yposition ;
                                           if(users[i].w->breaking_points.size()==0)
                                           {
                                               fbx=users[i].w->tail.Xposition;
                                               fby=users[i].w->tail.Yposition;
                                           }
                                           else
                                           {
                                               fbx=users[i].w->breaking_points[0].Xposition;
                                               fby=users[i].w->breaking_points[0].Yposition;
                                           }
                                       }
                                    }
                                    else
                                    {
                                       if(X<users[j].w->breaking_points[0].Xposition && X>=users[j].w->tail.Xposition)
                                       {
                                           users[i].w->decrease_lenght();
                                           X=users[i].w->head.Xposition ;
                                           Y=users[i].w->head.Yposition ;
                                           if(users[i].w->breaking_points.size()==0)
                                           {
                                               fbx=users[i].w->tail.Xposition;
                                               fby=users[i].w->tail.Yposition;
                                           }
                                           else
                                           {
                                               fbx=users[i].w->breaking_points[0].Xposition;
                                               fby=users[i].w->breaking_points[0].Yposition;
                                           }
                                       }
                                    }
                                   }
                               }
                           }
                           else
                           {
                               for(int z=0 ;z<users[j].w->breaking_points.size()-1;z++)
                               {
                                 if(users[j].w->breaking_points[z].Yposition == users[j].w->breaking_points[z+1].Yposition)
                                 {
                                    if(Y<=users[j].w->breaking_points[z].Yposition && fby >=users[j].w->breaking_points[z].Yposition )
                                    {
                                        if(z==0)
                                        {
                                            if(X==users[j].w->breaking_points[0].Xposition)
                                            {
                                               if(users[j].w->head.Yposition > users[j].w->breaking_points[0].Yposition)
                                               {
                                                   users[i].w->decrease_lenght();
                                                   users[j].w->decrease_lenght();
                                                   X=users[i].w->head.Xposition ;
                                                   Y=users[i].w->head.Yposition ;
                                                   if(users[i].w->breaking_points.size()==0)
                                                   {
                                                       fbx=users[i].w->tail.Xposition;
                                                       fby=users[i].w->tail.Yposition;
                                                   }
                                                   else
                                                   {
                                                       fbx=users[i].w->breaking_points[0].Xposition;
                                                       fby=users[i].w->breaking_points[0].Yposition;
                                                   }
                                               }
                                               else
                                               {
                                                   users[i].w->decrease_lenght();

                                                   X=users[i].w->head.Xposition ;
                                                   Y=users[i].w->head.Yposition ;
                                                   if(users[i].w->breaking_points.size()==0)
                                                   {
                                                       fbx=users[i].w->tail.Xposition;
                                                       fby=users[i].w->tail.Yposition;
                                                   }
                                                   else
                                                   {
                                                       fbx=users[i].w->breaking_points[0].Xposition;
                                                       fby=users[i].w->breaking_points[0].Yposition;
                                                   }
                                               }
                                               continue;
                                            }
                                        }
                                        if(users[j].w->breaking_points[z].Xposition >users[j].w->breaking_points[z+1].Xposition )
                                        {
                                           if(X>=users[j].w->breaking_points[z+1].Xposition && X<=users[j].w->breaking_points[z].Xposition )
                                           {
                                               users[i].w->decrease_lenght();
                                               X=users[i].w->head.Xposition ;
                                               Y=users[i].w->head.Yposition ;
                                               if(users[i].w->breaking_points.size()==0)
                                               {
                                                   fbx=users[i].w->tail.Xposition;
                                                   fby=users[i].w->tail.Yposition;
                                               }
                                               else
                                               {
                                                   fbx=users[i].w->breaking_points[0].Xposition;
                                                   fby=users[i].w->breaking_points[0].Yposition;
                                               }
                                           }
                                        }
                                        else
                                        {
                                            if(X>=users[j].w->breaking_points[z].Xposition && X<=users[j].w->breaking_points[z+1].Xposition)
                                            {
                                                users[i].w->decrease_lenght();
                                                X=users[i].w->head.Xposition ;
                                                Y=users[i].w->head.Yposition ;
                                                if(users[i].w->breaking_points.size()==0)
                                                {
                                                    fbx=users[i].w->tail.Xposition;
                                                    fby=users[i].w->tail.Yposition;
                                                }
                                                else
                                                {
                                                    fbx=users[i].w->breaking_points[0].Xposition;
                                                    fby=users[i].w->breaking_points[0].Yposition;
                                                }
                                            }
                                        }
                                    }
                                 }
                               }
                               if(users[j].w->rasta_tail== 'h')
                               {
                                  int t =users[j].w->breaking_points.size()-1 ;
                                  if(Y<=users[j].w->tail.Yposition && fby >= users[j].w->tail.Yposition)
                                  {
                                      if(users[j].w->tail.Xposition >users[j].w->breaking_points[t].Xposition )
                                      {
                                         if(X>=users[j].w->breaking_points[t].Xposition && X<=users[j].w->tail.Xposition)
                                         {
                                             users[i].w->decrease_lenght();
                                             X=users[i].w->head.Xposition ;
                                             Y=users[i].w->head.Yposition ;
                                             if(users[i].w->breaking_points.size()==0)
                                             {
                                                 fbx=users[i].w->tail.Xposition;
                                                 fby=users[i].w->tail.Yposition;
                                             }
                                             else
                                             {
                                                 fbx=users[i].w->breaking_points[0].Xposition;
                                                 fby=users[i].w->breaking_points[0].Yposition;
                                             }
                                         }
                                      }
                                      else
                                      {
                                         if(X>=users[j].w->tail.Xposition && X<=users[j].w->breaking_points[t].Xposition)
                                         {
                                             users[i].w->decrease_lenght();
                                             X=users[i].w->head.Xposition ;
                                             Y=users[i].w->head.Yposition ;
                                             if(users[i].w->breaking_points.size()==0)
                                             {
                                                 fbx=users[i].w->tail.Xposition;
                                                 fby=users[i].w->tail.Yposition;
                                             }
                                             else
                                             {
                                                 fbx=users[i].w->breaking_points[0].Xposition;
                                                 fby=users[i].w->breaking_points[0].Yposition;
                                             }
                                         }
                                      }
                                  }
                               }
                           }
                        }
                     }
                   }
                }
              }
            }
        }
    }
    emit(state_calculated(id));
}
 game:: ~game()
 {
   users.clear();
   increasing_points.clear();
   delete timer ;
 }

 void game::delete_user(int index)
 {
   if(index == users.size()-1)
       users.pop_back();
   else
   {
       users[index]=users.back();
       users.pop_back();
   }
 }

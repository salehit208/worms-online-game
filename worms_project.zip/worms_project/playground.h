#include <coordinates.h>
#include <vector>
using namespace std;
#ifndef PLAYGROUND_H
#define PLAYGROUND_H

class wall{
 public:
    short type;
    coordinates top_left ;
};

class playground{
  public:
    vector<wall> walls ;
};

#endif // PLAYGROUND_H

#ifndef SERVER_H
#define SERVER_H

#include <QObject>
#include <QUdpSocket>
#include <QHostAddress>
#include <vector>
#include <user.h>
#include <game.h>
#include <playground.h>
#include <QSqlDatabase>
#include <QTimer>
using namespace std;
class server : public QObject
{
    Q_OBJECT
public:
    vector<game *> games ;
    vector<user> authenticated_users ;
    QUdpSocket * _socket ;
    playground * playgrounds ;
    vector<user> waiting_for_playing;
    QSqlDatabase db ;
    QTimer start_new_game ;
    int the_highest_availble_id ;
    vector<int> removed_game_ids;
public:
    explicit server(QObject *parent = 0);
    ~server();


public slots:
    void ready_read();
    void send_state(int id_game);
    void add_new_game();

};

#endif // SERVER_H

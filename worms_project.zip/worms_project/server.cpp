#include "server.h"
#include <QString>
#include <iostream>
#include <QSqlQuery>
#include <game.h>
#include <iostream>
#include <QHostAddress>
#include <string>
#include <QByteArray>
#include <user.h>
using namespace std ;
server::server(QObject *parent) :
    QObject(parent)
{
  _socket=new QUdpSocket;
  _socket->bind(QHostAddress :: Any,2000);
  connect(_socket,SIGNAL(readyRead()),this,SLOT(ready_read()));
  playgrounds = new playground;
  connect(&start_new_game,SIGNAL(timeout()),this,SLOT(add_new_game()));
  start_new_game.start(10000);
  QString connectionTemplate = "DRIVER={SQL SERVER};SERVER=%1;DATABASE=%2;";
  QString _server="DESKTOP-28A3DB5";
  QString database ="worm_project";
  QString connectionstring=connectionTemplate.arg(_server).arg(database);
  db=QSqlDatabase ::addDatabase("QODBC");
  db.setDatabaseName(connectionstring);
  the_highest_availble_id =1 ;
  // if(db.open())
//  {

//  }
//  game  * g=new game(0,3);
//  games.push_back(g);
//  games[0]->timer->start(250);
 // connect(games[0],SIGNAL(state_calculated(int )),this,SLOT(send_state(int )));
}


void server::ready_read()
{
    cout <<"message received"<<endl ;
    //char received_data[50];
    QHostAddress  user_address;
    quint16  user_port;
    while(_socket->hasPendingDatagrams())
    {
       char received_data[_socket->pendingDatagramSize()];
       cout <<_socket->pendingDatagramSize()<<endl ;
     cout << _socket->readDatagram(received_data,_socket->pendingDatagramSize(),&user_address,&user_port)<<endl ;
      cout <<"we have packets"<<"  "<<"with typ"<<"   "<<received_data[0] <<endl ;
      if(received_data[0]=='c')
      {
          int username_chractrer_number=received_data[1];
          char incoming_username[username_chractrer_number+1];
          int index=0;
          for(int i=2;i<username_chractrer_number+2;i++)
          {
              incoming_username[index]=received_data[i];
              index++;
          }
          incoming_username[username_chractrer_number]=0;
          int password_character_number=received_data[username_chractrer_number+2];
          char incoming_password[password_character_number+1] ;
          index= 0;
          for(int i=username_chractrer_number+3;i<username_chractrer_number+3+password_character_number;i++)
          {
              incoming_password[index]=received_data[i];
              index++;
          }
          incoming_password[password_character_number]=0;
          cout <<"new user with username:"<<"  "<<incoming_username<<" "<<"and password:"<<"  "<<incoming_password<<endl ;
          if(db.open())
          {
              QSqlQuery q;
              q.prepare("select * from user_table where username=:u ");
              QString u(incoming_username);
              q.bindValue(0,u);
              q.exec();
              q.next();
              if(q.isValid())
              {
                 char sending_data[2];
                 sending_data[0]='c';
                 sending_data[1]='f';
                 cout <<"adding new user failed"<<endl ;
                 _socket->writeDatagram(sending_data,2,user_address,user_port);


              }
              else
              {
                  QSqlQuery insert_new_user;
                  insert_new_user.prepare("insert into user_table (username,password) values (:username,:password)");
                  QString p(incoming_password) ;
                  insert_new_user.bindValue(0,u);
                  insert_new_user.bindValue(1,p);
                  insert_new_user.exec();
                  user new_user(username_chractrer_number,password_character_number,user_address,user_port,incoming_username,incoming_password);
                  authenticated_users.push_back(new_user);
                  char sending_data[2];
                  sending_data[0]='c';
                  sending_data[1]='p';
                  cout <<"new user added"<<endl ;
                  _socket->writeDatagram(sending_data,2,user_address,user_port);

              }
          }
      }
      if(received_data[0]=='a')
      {
          int username_chractrer_number=received_data[1];
          char incoming_username[username_chractrer_number+1];
          int index=0;
          for(int i=2;i<username_chractrer_number+2;i++)
          {
              incoming_username[index]=received_data[i];
              index++;
          }
          incoming_username[username_chractrer_number]=0;
          int password_character_number=received_data[username_chractrer_number+2];
          char incoming_password[password_character_number+1] ;
          index= 0;
          for(int i=username_chractrer_number+3;i<username_chractrer_number+3+password_character_number;i++)
          {
              incoming_password[index]=received_data[i];
              cout <<(int)incoming_password[index]<<endl ;
              index++;
          }
          incoming_password[password_character_number]=0 ;
          cout <<"user with username:"<<"  "<<incoming_username<<" "<<"and password:"<<"  "<<QString(incoming_password).toInt()<<"  "<<"wants to authenticate"<<endl ;
          if(db.open())
          {
              QSqlQuery q;
              q.prepare("select * from user_table where username=:u and password=:p ");
              QString u(incoming_username);
              QString p(incoming_password);
              q.bindValue(0,u);
              q.bindValue(1,p);
              q.exec();
              q.next();
              if(q.isValid())
              {
                  user new_user(username_chractrer_number,password_character_number,user_address,user_port,incoming_username,incoming_password);
                  authenticated_users.push_back(new_user);
                  char sending_data[2];
                  sending_data[0]='a';
                  sending_data[1]='p';
                  cout << "user authenticated"<<endl ;
                  _socket->writeDatagram(sending_data,2,user_address,user_port);

              }
              else
              {
                  char sending_data[2];
                  sending_data[0]='a';
                  sending_data[1]='f';
                   cout << "user_authentication failed"<<endl ;
                  _socket->writeDatagram(sending_data,2,user_address,user_port);

              }
          }
      }
      if(received_data[0]=='p')
      {

          int username_chractrer_number=received_data[1];
          char incoming_username[username_chractrer_number+1];
          int index=0;
          for(int i=2;i<username_chractrer_number+2;i++)
          {
              incoming_username[index]=received_data[i];
              index++;
          }
          incoming_username[username_chractrer_number]=0;
          int ground_id =received_data[username_chractrer_number+2];
          cout <<"player"<<"  "<<incoming_username<<"  "<<"choosed playground 1"<<endl ;
          string incoming_user(incoming_username);
          for(int i=0;i<authenticated_users.size();i++)
          {
             string a_u(authenticated_users[i].username) ;
             if(incoming_user == a_u)
             {
                 if(ground_id == 1)
                 {
                     waiting_for_playing.push_back(authenticated_users[i]);
                     for(int j=i;j<authenticated_users.size()-1;j++)
                         authenticated_users[j]=authenticated_users[j+1];
                     authenticated_users.pop_back();
                     break ;
                 }
             }

          }
      }
      if(received_data[0]=='n')
      {
          int username_chractrer_number=received_data[1];
          char incoming_username[username_chractrer_number+1];
          int index=0;
          for(int i=2;i<username_chractrer_number+2;i++)
          {
              incoming_username[index]=received_data[i];
              index++;
          }
          incoming_username[username_chractrer_number]=0;
          int game_id =received_data[username_chractrer_number+2];
          char jahat= received_data[username_chractrer_number+3];
          cout << "user"<<"  "<<incoming_username<<"  "<<"moved to  "<<"  "<<jahat<<endl ;
          cout <<received_data<<endl ;
          for(int i=0;i<games.size();i++)
          {
              if(games[i]->id == game_id)
              {
                  string incoming_user(incoming_username);
                  for(int j=0;j<games[i]->users.size();j++)
                  {
                      string p_u(games[i]->users[j].username);
                      if(incoming_user == p_u)
                      {
                          if(games[i]->users[j].w->lenght != 0)
                          {
                              games[i]->move_worm(games[i]->users[j].username,jahat);
                          }
                          break ;
                      }
                  }
                  break ;
              }
          }
      }
    }
}

void server::send_state(int id_game)
{
   for(int i=0;i<games.size();i++)
   {
       if(games[i]->id == id_game)
       {
         int sending_message_size = 2 ;
         int iterator=games[i]->users.size();
         int index =0 ;
         for(int j=0;j<iterator;j++)
         {
             if(games[i]->users[index].w->lenght == 0)
             {
                 char sending_data[2];
                 sending_data[0]='s';
                 sending_data[1]='o';
                 _socket->writeDatagram(sending_data,2,games[i]->users[index].address,games[i]->users[index].port);
                 delete games[i]->users[index].username ;
                 delete games[i]->users[index].password ;
                 delete games[i]->users[index].w ;
                 games[i]->users[index] = games[i]->users.back();
                 games[i]->users.pop_back();

             }
             else
             {
                 sending_message_size +=(games[i]->users[index].w->breaking_points.size()*2)+5;
                 index ++ ;
             }

         }
         if(games[i]->users.size() <=1)
         {
             if(games[i]->users.size()==1)
             {

                 char sending_data[2];
                 sending_data[0]='s';
                 sending_data[1]='w';
                 _socket->writeDatagram(sending_data,2,games[i]->users[0].address,games[i]->users[0].port);
                 delete games[i]->users[0].username ;
                 delete games[i]->users[0].password ;
                 delete games[i]->users[0].w ;
             }
             delete games[i]->timer ;
             games[i]->increasing_points.clear();
             games[i]=games.back();
             games.pop_back();
             break ;
         }
         else
         {
             char sending_data[sending_message_size+8];
             sending_data[0]='s';
             sending_data[1]=games[i]->users.size();

             for(int k=0;k<games[i]->users.size();k++)
             {
                 int sending_data_index =2;
                 sending_data[sending_data_index]=games[i]->users[k].w->breaking_points.size();
                 sending_data_index ++ ;
                 sending_data[sending_data_index]=games[i]->users[k].w->tail.Xposition ;
                 sending_data_index ++;
                 sending_data[sending_data_index]=games[i]->users[k].w->tail.Yposition ;
                 sending_data_index ++;
                 for(int z=games[i]->users[k].w->breaking_points.size()-1;z>=0;z--)
                 {
                     sending_data[sending_data_index]=games[i]->users[k].w->breaking_points[z].Xposition;
                     sending_data_index ++;
                     sending_data[sending_data_index]=games[i]->users[k].w->breaking_points[z].Yposition;
                     sending_data_index ++ ;
                 }
                 sending_data[sending_data_index]=games[i]->users[k].w->head.Xposition;
                 sending_data_index ++;
                 sending_data[sending_data_index]=games[i]->users[k].w->head.Yposition;
                 sending_data_index ++ ;
                 for(int h=0;h<games[i]->users.size();h++)
                 {
                     if(h != k)
                     {
                         sending_data[sending_data_index]=games[i]->users[h].w->breaking_points.size();
                         sending_data_index ++ ;
                         sending_data[sending_data_index]=games[i]->users[h].w->tail.Xposition ;
                         sending_data_index ++ ;
                         sending_data[sending_data_index]=games[i]->users[h].w->tail.Yposition ;
                         sending_data_index ++ ;
                         for(int z=games[i]->users[h].w->breaking_points.size()-1;z>=0;z--)
                         {
                             sending_data[sending_data_index]=games[i]->users[h].w->breaking_points[z].Xposition;
                             sending_data_index ++;
                             sending_data[sending_data_index]=games[i]->users[h].w->breaking_points[z].Yposition;
                             sending_data_index ++ ;
                         }
                         sending_data[sending_data_index]=games[i]->users[h].w->head.Xposition;
                         sending_data_index ++;
                         sending_data[sending_data_index]=games[i]->users[h].w->head.Yposition;
                         sending_data_index ++ ;
                     }
                 }
                 for(int w=0;w<games[i]->increasing_points.size();w++)
                 {
                     sending_data[sending_data_index]=games[i]->increasing_points[w].Xposition ;
                     sending_data_index ++;
                     sending_data[sending_data_index]=games[i]->increasing_points[w].Yposition ;
                     sending_data_index ++;
                 }
                _socket->writeDatagram(sending_data,sending_message_size+8,games[i]->users[k].address,games[i]->users[k].port);
             }
         }

       }
   }
}

void server::add_new_game()
{
 if(waiting_for_playing.size()>1)
  {
     cout <<"adding new game"<<endl ;
     int new_game_id ;
     if(removed_game_ids.size()==0)
     {
         new_game_id = the_highest_availble_id ;
         the_highest_availble_id ++;
     }
     else
     {
         new_game_id = removed_game_ids[removed_game_ids.size()-1];
         removed_game_ids.pop_back();
     }
     game * new_game = new game(0,new_game_id,playgrounds);
     int index =1;

     for(int i=0;i<4;i++)
     {
       if(waiting_for_playing.size()==0)
       {
           break ;
       }
       user starting_newgame(waiting_for_playing[0].username_character_number,waiting_for_playing[0].password_character_number,waiting_for_playing[0].address
               ,waiting_for_playing[0].port,waiting_for_playing[0].username,waiting_for_playing[0].password);
       coordinates tail;
       coordinates head ;
       if(index == 1)
       {
           tail.Xposition=4;
           tail.Yposition=20;
           head.Xposition=7;
           head.Yposition = 20 ;
           starting_newgame.creat_worm(head,tail,'h','h');
       }
       if(index == 2)
       {
           tail.Xposition=23;
           tail.Yposition=20;
           head.Xposition=20;
           head.Yposition = 20 ;
           starting_newgame.creat_worm(head,tail,'h','h');
       }
       if(index == 3)
       {
           tail.Xposition=13;
           tail.Yposition=4;
           head.Xposition=13;
           head.Yposition = 7 ;
           starting_newgame.creat_worm(head,tail,'v','v');
       }
       if(index == 4)
       {
           tail.Xposition=13;
           tail.Yposition=37;
           head.Xposition=13;
           head.Yposition = 34 ;
           starting_newgame.creat_worm(head,tail,'v','v');
       }
       new_game->add_user(starting_newgame);
       for(int j=0;j<waiting_for_playing.size()-1;j++)
           waiting_for_playing[j]=waiting_for_playing[j+1];
       waiting_for_playing.pop_back();
       index ++ ;
     }
    // index -- ;
     games.push_back(new_game);
     char sending_data[(new_game->users.size()*4)+3+8];
     sending_data[0]='g' ;
     sending_data[1]=new_game_id;
     sending_data[2]=new_game->users.size() ;
     for(int i=0;i<new_game->users.size();i++)
     {
         sending_data[3]=new_game->users[i].w->tail.Xposition;
         sending_data[4]=new_game->users[i].w->tail.Yposition;
         sending_data[5]=new_game->users[i].w->head.Xposition;
         sending_data[6]=new_game->users[i].w->head.Yposition;
         int sending_data_index =7 ;
         for(int j=0;j<new_game->users.size();j++)
         {
             if(j!= i)
             {
                 sending_data[sending_data_index]=new_game->users[j].w->tail.Xposition;
                 sending_data_index++;
                 sending_data[sending_data_index]=new_game->users[j].w->tail.Yposition;
                 sending_data_index ++ ;
                 sending_data[sending_data_index]=new_game->users[j].w->head.Xposition;
                 sending_data_index ++ ;
                 sending_data[sending_data_index]=new_game->users[j].w->head.Yposition;
                 sending_data_index ++ ;
             }
         }
         for(int j=0;j<new_game->increasing_points.size();j++)
         {
             sending_data[sending_data_index]=new_game->increasing_points[j].Xposition ;
             sending_data_index ++;
             sending_data[sending_data_index]=new_game->increasing_points[j].Yposition ;
             sending_data_index ++;
         }
         _socket->writeDatagram(sending_data,(new_game->users.size()*4)+3+8,new_game->users[i].address,new_game->users[i].port);
         cout <<"new game added successfully"<<endl ;
     }
     connect(games[games.size()-1],SIGNAL(state_calculated(int )),this,SLOT(send_state(int )));
     games[games.size()-1]->timer->start(100);
 }

}

 server::~server()
{
    db.close();
   // delete db ;
    _socket->close();
    delete _socket ;
    authenticated_users.clear();
    waiting_for_playing.clear();
    for(int i=0;i<games.size();i++)
    {
        delete games[i];
    }
}
